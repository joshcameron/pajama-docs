def version() -> str:

	# This version string is replaced during the build. You will only see zeros when running from
	# source.
	return 'v0.1.20250725030301' 


def version_and_hash() -> str:
	"""
	Return the version number and commit hash of the pajama build system.

	Returns:
			A string containing the version number and commit hash.
	"""

	# This version string is replaced during the build. You will only see zeros when running from
	# source.
	return 'v0.1.20250725030301-5e7a089' 
