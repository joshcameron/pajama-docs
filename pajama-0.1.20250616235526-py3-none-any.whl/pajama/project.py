"""
Finds the project root directory and its contents.
"""

import os
from pathlib import Path


def find_root() -> str | None:
	"""
	Seek out the root directory of the build. Start from cwd and look upward
	until a directory containing a .pajama-project subdirectory is found.

	Returns:
			The path of the root directory, or None, if the working directory
			is not part of a pajama build.
	"""

	result = None
	path = os.getcwd()

	while True:

		pajama_dir_path = os.path.join(path, ".pajama-project")

		if os.path.isdir(pajama_dir_path):
			# We've found a directory containing a .pajama subdirectory.
			# This is a pajama project directory.
			result = path
			break

		path = os.path.dirname(path)

		if os.path.ismount(path):
			# We've reached the root of the filesystem without finding a
			# pajama project directory.
			break

	return result


class Project:
	"""
	Represents a pajama project.
	"""

	def __init__(self, root: str):
		"""
		Initialize the project with the given root directory.
		"""
		assert os.path.isdir(root), f"Project root '{root}' is not a directory."
		self.root = root
		self.name = os.path.basename(self.root)
		self.project_dir = Path(self.root) / '.pajama-project'
		self.dotenv_path = os.path.join(self.root, '.env')
		self.dotenv_local_path = os.path.join(self.root, '.env.local')
		self.config_path = os.path.join(self.root, '.pajama-project', 'config.toml')
		self.config_local_path = os.path.join(self.root, '.pajama-project', 'config.local.toml')


	def __repr__(self):
		return f"Project(root={self.root})"

