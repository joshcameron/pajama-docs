from pathlib import Path

import tomllib
from pajama import project


class Config:

	def __init__(self, project: project.Project):
		pass
		self.project = project
		self.project_config = self.load_config(self.project.project_dir / 'config.toml')
		self.project_local_config = self.load_config(self.project.project_dir / 'config.local.toml')
		self.user_config = self.load_config(Path.home() / '.config' / 'pajama' / 'config.toml')


	def load_config(self, config_path: Path):
		"""
		Load the configuration from a TOML file.

		Args:
			config_path: The path to the configuration file.
		"""

		if config_path.exists():

			with config_path.open('rb') as file:

				config = tomllib.load(file)
				print(f'{config_path}: {config}\n')

				return config

		return None


