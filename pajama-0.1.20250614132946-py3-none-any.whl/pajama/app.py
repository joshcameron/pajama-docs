import datetime
import os
import pdb
import sys
import time
import traceback
from pathlib import Path

from pajama import config, environment, log, project
from pajama.impl import build, session


def version_and_hash() -> str:
	"""
	Return the version number and commit hash of the pajama build system.

	Returns:
			A string containing the version number and commit hash.
	"""

	# This version string is replaced during the build. You will only see zeros when running from
	# source.
	return 'v0.0.0-dev' 


class Application:

	def __init__(
			self,
			exe_dir: Path,
			command: str, 
			options: dict, 
			args: dict):

		project_root = project.find_root()

		if not project_root:

			raise RuntimeError("Error: Not in a pajama project directory.")

		self.project = project.Project(project_root)
		self.exe_dir = exe_dir
		self.command = command
		self.options = options
		self.args = args
		self.config = config.Config(self.project)

		pass_through_vars = []
		self.environment = environment.Environment(
			[self.project.dotenv_path, self.project.dotenv_local_path],
			pass_through_vars)

		self.src_dir = self.project.root

		# Pajama was invoked from within a pajama project.

		if command == 'build':

			if self.options['build']['build_dir']:

				self.build_dir = self.options['build']['build_dir']

			else:

				# TODO: Also check .env and config files for build_dir.
				self.build_dir = os.path.join(self.project.root, "build")

		self.build_dir = None
		self.inventory_dir = None
		self.collection_dirs = []


	def configure(self):

		# Read config.toml
		#project_config = self.load_config(self.project.project_dir / 'config.toml')
		#user_config = self.load_config(self.project.project_dir / f'config.{user_name}.toml')

		# Read command line options

		# Clear os.environ to avoid loading existing system environment variables
		os.environ.clear()
		os.environ.update(self.environment.as_dict())

		self.build_dir = f"/Users/joshcameron/Builds/{self.project.name}"
		self.inventory_dir = os.path.join(self.build_dir, ".pajama-inventory")

		# TODO: These should be configured by command line flag or config file.
		self.collection_dirs.append("/Users/joshcameron/Projects/pajama/src/collection")
		# TODO: For the time being, the default collection is integrated into
		# the built-in collection.
		# self.collection_dirs.append(
		# '/Users/joshcameron/Projects/default-pajama-collection')
		# self.collection_dirs.append(
		# '/Users/joshcameron/Projects/custom-pajama-collection')


	def perform_build(self):

		# pylint: disable=used-before-assignment
		self.build = build.Build(
			src_dir=self.src_dir,
			build_dir=self.build_dir,
			inventory_dir=self.inventory_dir,
			collection_dirs=self.collection_dirs)

		if self.options['build']["clean"]:

			self.build.clean_phase()

		self.build.inventory_phase()
		self.build.build_phase()
		self.build.summarize()
		self.build.check_integrity()


	def run(self):

		log.info(f"pajama {version_and_hash()}")

		self.limit_python_path()
		self.configure()
		self.perform_build()


	def limit_python_path(self):

		"""
		Limit sys.path (ie PYTHONPATH) to only those modules installed in the
		python installation we are using (eg stuff in site_packages). This
		allows code to import standard Python modules, but reduces the risk of
		importing python modules we don't expect to import.
		"""

		# TODO allow the user to enable/disable this minimization using a
		# command line flag.

		# TODO allow the user to explicitly add to the PYTHONPATH using a
		# command line flag. This allows the user to import from directories
		# other than the site_packages of the Python executable, but also
		# allows us to track what python modules are available and whether
		# they have changed since the previous build.

		# TODO TEST that we have not introduced any dependencies on packages
		# which don't exist in a standard Python distribution. Or TEST that
		# we only depend on packages which are in the standard Python
		# distribution or part of an explicit list we require when pajama is
		# installed.

		limited_sys_path = []

		# We want to keep in sys.path the directories which are part of the
		# Python installation, so code can import standard Python modules.

		python_bin_dir = os.path.dirname(os.path.realpath(sys.executable))
		python_install_dir = os.path.dirname(python_bin_dir)

		for path in sys.path:

			if path.startswith(python_install_dir):

				limited_sys_path.append(path)

        # Add pajama's built-in collection directory to sys.path.
		pajama_collection_dir = self.exe_dir.parent / 'collection'
		limited_sys_path.append(str(pajama_collection_dir))
		pajama_src_dir = self.exe_dir.parent
		limited_sys_path.append(str(pajama_src_dir))

		sys.path = limited_sys_path

		# TODO tag this output
		log.debug("limit_python_path setting sys.path to: {str(sys.path)}", tag="python")


def on_uncaught_exception(exception_type, value, tb):
	"""
	Handle uncaught exceptions by dropping into the debugger.

    Args:
        exception_type: The type of the exception.
        value: The exception object.
        tb: The traceback object.
	"""

	if hasattr(sys, 'ps1') or not sys.stderr.isatty() or exception_type is not AssertionError:

		# We are in interactive mode or we don't have a tty-like
		# device, so we call the default uncaught exception handler.
		sys.__excepthook__(exception_type, value, tb)

	else:

		# We are NOT in interactive mode. Print the exception.
		traceback.print_exception(exception_type, value, tb)
		print()

		# Start the debugger in post-mortem mode.
		pdb.pm()


def invoke(exe_dir: Path, command: str, options: dict, args: dict):

	# Register our custom uncaught exception handler.
	sys.excepthook = on_uncaught_exception

	session.begin()

	wall_clock_tick = time.perf_counter()
	process_tick = time.process_time()

	application = Application(exe_dir, command, options, args)
	application.run()

	wall_clock_tock = time.perf_counter()
	process_tock = time.process_time()
	wall_clock_duration = wall_clock_tock - wall_clock_tick
	process_duration = process_tock - process_tick

	log.info(f"Build duration (wall clock): {wall_clock_duration}s", tag="stats")
	log.info(f"Build duration (process):    {process_duration}s", tag="stats")

	# Record a history of build times to file.
	# TODO This is useful, but we cannot let the file continue to grow
	# indefinitely.
	# TODO By default, we should not pollute the user's project directory with
	# this file.
	with open(".pajama-project/build-time.csv", "a", encoding="utf-8") as file:

		file.write(f"{datetime.datetime.now(datetime.UTC).isoformat()}, {wall_clock_duration}\n")


