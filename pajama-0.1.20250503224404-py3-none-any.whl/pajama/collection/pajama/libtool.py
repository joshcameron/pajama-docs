import os

from pajama import artifact, settings
from pajama.impl import exception, libtool, tool, tool_selection_action


# TODO This code is nearly identical to cpp.select_compiler(). Refactor.
def select(min_version: str | None = None, max_version: str | None = None):

	"""
	Request the use of libtool in the specified version range.

	Args:
		min_version: The minimum version of libtool to use.
		max_version: The maximum version of libtool to use.
	"""

	tool_id = 'libtool'

	exception.type_check('tool_id', tool_id, str)
	exception.type_check('min_version', min_version, (str, type(None)))
	exception.type_check('max_version', max_version, (str, type(None)))

	# TODO also accept StringArtifact or Version for min_version, max_version?
	# TODO preferred_version = Version.LATEST (vs Version.EARLIEST)
	# TODO allow preferred version to be a specific version?

	tool_cls = tool.get_tool_cls(tool_id) 

	# The specified tool should be a compiler 
	# TODO raise an exception instead of asserting
	# TODO tools should have a tool_type in addition to a tool_id. tool_type should be a str,
	# and users should be able to query for available tools by tool_type.
	assert isinstance(tool_cls, type(libtool.Linker))

	input_artifacts = {}

	input_artifacts['tool_id'] = artifact.StringArtifact(tool_id)

	if min_version:

		input_artifacts['min_version'] = \
			artifact.VersionArtifact(tool_cls.version_from_str(min_version))

	if max_version:

		input_artifacts['max_version'] = \
			artifact.VersionArtifact(tool_cls.version_from_str(max_version))

	selection_action = tool_selection_action.ToolSelectionAction(input_artifacts)

	# log.debug(f'{tool_id} tool_artifact = {id(tool_artifact)}')

	# Push tool onto tool stack, so it will be used for subsequent actions requiring this tool.
	# At this point, the tool artifact is a placeholder -- the actual tool to be used has not been
	# discovered or selected.

	settings.set('libtool.tool', selection_action.output_artifacts['tool'])



def create_library(
		object_files: list,
		library_base_name: str,
		dynamic: bool = True):

	"""
	Link object files into a static or dynamic library.

	Args:

		object_files: \
			The object files to link.

		library_base_name: \
			The base name of the library. The base name will be prefixed with lib and suffixed \
			with .a for a static library, or .dylib for a dynamic library.
	"""

	exception.type_check('object_files', object_files, (list))
	exception.type_check('library_base_name', library_base_name, (str))

	input_artifacts = {}

	input_artifacts['object_files'] = artifact.ListOfArtifacts()

	for object_file in object_files:

		if isinstance(object_file, artifact.FileArtifact):

			input_artifacts['object_files'].append(object_file)

		elif isinstance(object_file, str):

			input_artifacts['object_files'].append(
				artifact.FileArtifact(os.path.abspath(object_file)))

		else:

			# The object_files argument must be a list containing only FileArtifact or str items.
			raise TypeError


	# Derive the library file name from the base name and the type of library (dynamic vs static)
	if dynamic:

		library_file_name = f'lib{library_base_name}.dylib'

	else:

		library_file_name = f'lib{library_base_name}.a'

	input_artifacts['library_file_name'] = artifact.StringArtifact(library_file_name)


	#libtool_artifact = settings.get('libtool.tool')
	## TODO create a new exception type -- tool used before it is selected -- and raise it here.
	#assert libtool_artifact is not None
	#assert isinstance(libtool_artifact, tool_artifact.ToolArtifact)

	# Instantiate an action to create the library.
	link_library_action = libtool.LinkLibraryAction(input_artifacts)

	return link_library_action.output_artifacts['library_file']


# When this module is imported, select the latest libtool tool by default.
if not settings.contains('libtool.tool'):

	select()
