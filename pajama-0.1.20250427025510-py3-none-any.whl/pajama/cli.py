#!/usr/bin/env python3

"""
The executable invoked when a user types 'pajama' on the command line.
"""
# It is responsible for:
# - Defining, parsing and validating command line options.
# - Limiting the system path.
# - Finding the appropriate top level .pajama file to include.
# - Instantiating the build and including the top level .pajama file.

import argparse
import cProfile
import datetime
import os
import pstats
import sys
import time

# pyright: reportMissingImports=false


def version_and_hash() -> str:
	"""
	Return the version number and commit hash of the pajama build system.

	Returns:
			A string containing the version number and commit hash.
	"""

	# This version string is replaced during the build. You will only see zeros when running from
	# source.
	return 'v0.1.20250427025510-e4ce1a9' 


def find_project_root():
	"""
	Seek out the root directory of the build, by continuing to look upward
	until a directory containing a .pajama-project subdirectory is found.

	Returns:
			The path of the root directory, or None, if the working directory
			is not part of a pajama build.
	"""

	result = None

	path = os.getcwd()

	while True:
		pajama_dir_path = os.path.join(path, ".pajama-project")

		if os.path.isdir(pajama_dir_path):
			# We've found a directory containing a .pajama subdirectory.
			# This is a pajama project directory.
			result = path
			break

		path = os.path.dirname(path)

		if os.path.ismount(path):
			# We've reached the root of the filesystem without finding a
			# pajama project directory.
			break

	return result


if __name__ == "__main__":

	# Based on the location of the pajama executable, we find the built-in collection. 
	pajama_dir = os.path.dirname(os.path.abspath(__file__))
	pajama_collection_dir = os.path.join(pajama_dir, "collection")

	# Add the collection directory to the system path so we may import modules from the collection.
	# sys.path.clear()
	sys.path.insert(0, pajama_collection_dir)

	if not find_project_root():
		print(f"{os.getcwd()} is not within a Pajama project.")
		print(
			"Pajama must be run from a directory containing a "
			".pajama-project directory, or under a directory "
			"containing a .pajama-project directory."
		)

		# TODO: Link to a url

		sys.exit(1)

	# Import modules from the collection, now that the collection is in the path.
	# pylint: disable=wrong-import-position
	# pylint: disable=ungrouped-imports
	# pylint: disable=import-error
	# ruff: noqa: E402
	import pajama.impl.session as session

	session.begin()

	import pajama.impl.build
	import pajama.impl.exception
	import pajama.log as log
	import pajama.options as options


USAGE = """
	pajama [global-options] <command> [command-options]

	For example:

	pajama build [args]
	pajama docs [args]

"""


class PajamaArgumentParser(argparse.ArgumentParser):

	def __init__(self, prog):

		super().__init__(
			prog=prog,
			usage=USAGE,
			description="Pajama build system",
			epilog="For more information see: https://pajama-build.com/docs",
		)


	def configure(self):

		# TODO Is there a standard for command line arguments? Find out if
		# there is and review what we have to see if we should do it
		# differently.

		verbosity = self.add_mutually_exclusive_group()
		verbosity.add_argument("-q, --quiet", action="store_true", help="Execute quietly")
		verbosity.add_argument("-v, --verbose", action="store_true", help="Execute verbosely")

		subparsers = self.add_subparsers(dest="command")

		subparsers.add_parser("build", help="Build the project (default command)")

		build_group = self.add_argument_group("build", "Build group description.")
		build_group.add_argument(
			"--clean",
			action="store_true",
			help="Clean the build directory before building")

		subparsers.add_parser("docs", help="Show documentation")

		# docs_group = self.add_argument_group(
		# 'docs',
		# 'Docs group description.')


	def format_help(self):

		# TODO Are there conventions about documenting usage? Are we following
		# them well?

		# Customize message output to be as readable as possible.
		result = super().format_help()
		# print(f'\n---\nOriginal argparse help:\n{result}\n---\n')
		result = result.replace("positional arguments:", "command:")
		result = result.replace("options:", "global-options:")
		result = result.replace("build:", "build command-options:")
		result = result.replace("docs:", "docs command-options:")
		result = result.replace("show this help", "Show this help")

		return result


class Application:

	def __init__(self):

		self.project_root = find_project_root()
		self.src_dir = None
		self.build_dir = None
		self.inventory_dir = None
		self.collection_dirs = []

		# print(f'sys.argv: {sys.argv!s}')
		self.args = self.parse_args()
		# print(f'self.args: {vars(self.args)}')


	def parse_args(self):

		# Parse command line arguments. What target? What
		# variant(s)/option(s)? Actually perform build? Or determine what
		# would be built? Or produce a diagram of the build?
		# Use a command structure like git, brew, etc? Commands could be like:
		# > pajama
		# > pajama some-target
		# > pajama build
		# > pajama build some-target
		# > pajama build --options debug
		# > pajama --graph some-target
		# > pajama --graph
		# > pajama build --dryrun
		# > pajama build --dryrun some-target
		# > pajama build --dryrun --options debug
		# > pajama build --discover-only

		parser = PajamaArgumentParser(prog="pajama")
		parser.configure()
		args = parser.parse_args()

		# log.debug(f'args: {vars(args)}')

		if args.command is None:
			# log.debug('No command specified. Defaulting to build.')
			args.command = "build"
			# If no command is specified, default to 'build'.
			# sys.argv.insert(1, 'build')
			# args = parser.parse_args()

		# log.debug(f'args: {vars(args)}')

		if args.command == "build" and args.clean:
			options.set("clean", True)

		return args


	def configure(self):
		# Read user env file
		# Read project env file
		# Read user config file
		# Read project config file

		self.src_dir = self.project_root
		project_name = os.path.basename(self.src_dir)
		self.build_dir = f"/Users/joshcameron/Builds/{project_name}"
		self.inventory_dir = os.path.join(self.build_dir, ".pajama-inventory")

		# TODO: These should be configured by command line flag or config file.
		self.collection_dirs.append("/Users/joshcameron/Projects/pajama/src/pajama/collection")
		# TODO: For the time being, the default collection is integrated into
		# the built-in collection.
		# self.collection_dirs.append(
		# '/Users/joshcameron/Projects/default-pajama-collection')
		# self.collection_dirs.append(
		# '/Users/joshcameron/Projects/custom-pajama-collection')


	def perform_build(self):

		# pylint: disable=used-before-assignment
		build = pajama.impl.build.Build(
			src_dir=self.src_dir,
			build_dir=self.build_dir,
			inventory_dir=self.inventory_dir,
			collection_dirs=self.collection_dirs)

		if options.get("clean"):

			build.clean_phase()

		build.inventory_phase()
		build.build_phase()
		build.summarize()
		build.check_integrity()


	def run(self):

		try:

			log.info(f"pajama {version_and_hash()}")

			self.limit_python_path()
			self.parse_args()
			self.configure()
			self.perform_build()

		except pajama.impl.exception.PajamaException as exception:

			log.error(f"{exception}")
			sys.exit(1)


	def limit_python_path(self):

		"""
		Limit sys.path (ie PYTHONPATH) to only those modules installed in the
		python installation we are using (eg stuff in site_packages). This
		allows code to import standard Python modules, but reduces the risk of
		importing python modules we don't expect to import.
		"""

		# TODO allow the user to enable/disable this minimization using a
		# command line flag.

		# TODO allow the user to explicitly add to the PYTHONPATH using a
		# command line flag. This allows the user to import from directories
		# other than the site_packages of the Python executable, but also
		# allows us to track what python modules are available and whether
		# they have changed since the previous build.

		# TODO TEST that we have not introduced any dependencies on packages
		# which don't exist in a standard Python distribution. Or TEST that
		# we only depend on packages which are in the standard Python
		# distribution or part of an explicit list we require when pajama is
		# installed.

		limited_sys_path = []

		# We want to keep in sys.path the directories which are part of the
		# Python installation, so code can import standard Python modules.

		python_bin_dir = os.path.dirname(os.path.realpath(sys.executable))
		python_install_dir = os.path.dirname(python_bin_dir)

		for path in sys.path:

			if path.startswith(python_install_dir):

				limited_sys_path.append(path)

		sys.path = limited_sys_path

		# TODO tag this output
		log.debug("limit_python_path setting sys.path to: {str(sys.path)}", tag="python")



def on_uncaught_exception(exception_type, value, tb):
	"""
	Handle uncaught exceptions by dropping into the debugger.

    Args:
        exception_type: The type of the exception.
        value: The exception object.
        tb: The traceback object.
	"""

	if hasattr(sys, 'ps1') or not sys.stderr.isatty() or exception_type is not AssertionError:

		# We are in interactive mode or we don't have a tty-like
		# device, so we call the default uncaught exception handler.
		sys.__excepthook__(exception_type, value, tb)

	else:

		# ruff: noqa: T100
		# ruff: noqa: I001
		import pdb # pylint: disable=import-outside-toplevel
		import traceback # pylint: disable=import-outside-toplevel

		# We are NOT in interactive mode. Print the exception.
		traceback.print_exception(exception_type, value, tb)
		print()

		# Start the debugger in post-mortem mode.
		pdb.pm()


def main():

	# Register our custom uncaught exception handler.
	sys.excepthook = on_uncaught_exception

	wall_clock_tick = time.perf_counter()
	process_tick = time.process_time()

	application = Application()
	application.run()

	wall_clock_tock = time.perf_counter()
	process_tock = time.process_time()
	wall_clock_duration = wall_clock_tock - wall_clock_tick
	process_duration = process_tock - process_tick

	log.info(f"Build duration (wall clock): {wall_clock_duration}s", tag="stats")
	log.info(f"Build duration (process):    {process_duration}s", tag="stats")

	# Record a history of build times to file.
	# TODO This is useful, but we cannot let the file continue to grow
	# indefinitely.
	# TODO By default, we should not pollute the user's project directory with
	# this file.
	with open(".pajama-project/build-time.csv", "a", encoding="utf-8") as file:

		file.write(f"{datetime.datetime.now(datetime.UTC).isoformat()}, {wall_clock_duration}\n")


if __name__ == "__main__":

	# TODO Move this stuff into main? When pip installed, the command line
	# invocation of pajama calls main() directly, bypassing profiling.

	WANT_PROFILE = True

	if WANT_PROFILE:

		# Profile pajama execution.
		# See https://docs.python.org/3.10/library/profile.html

		# Run main() and dump all profiling stats to file.
		profile = cProfile.Profile()
		profile.run("main()")
		profile.dump_stats(".pajama-project/profile.prof")

		with open(".pajama-project/profile.txt", "w", encoding="utf-8") as stream:

			# Load profiling stats from file and dump to a human readable
			# file.

			stats = pstats.Stats(".pajama-project/profile.prof", stream=stream)
			stats.strip_dirs()
			# stats.sort_stats('cumtime')
			stats.sort_stats("time")
			# stats.print_stats()
			stats.print_callers(20)

	else:

		main()
