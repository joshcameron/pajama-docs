#!/usr/bin/env python3

"""
Parses the pajama command line and invokes the pajama application.
Environment variables of the form "PAJAMA_<command>_<option>" -- if they exist -- are used to set 
default values for options.
This code is only concerned with parsing, and is not concerned with making appropriate decisions
based on the commands, options or arguments specified by the user.
"""

import json
import os
import sys
from pathlib import Path

import pajama.app
import pajama.project

import click


def invoke(project_root: str, command: str, options: dict, args: dict):
	"""
	Invoke a command with the given options and arguments.

	Args:
			command: The command to invoke.
			options: A dictionary of options for the command.
			args: A dictionary of arguments for the command.
	"""
	exe_dir = Path(os.path.dirname(os.path.abspath(__file__)))

	if 'PAJAMA_DEV_TEST_CLI' in os.environ:
	#if True:

		json.dump(
			{
				'exe_dir': str(exe_dir),
                'project_root': project_root,
				'command': command,
				'options': options,
				'args': args
			},
			sys.stdout, 
			indent=4)

	else:

		pajama.app.invoke(exe_dir, project_root, command, options, args)


def print_version(ctx, param, value):

    _ = param # Unused

    if not value or ctx.resilient_parsing:

        return

    click.echo(pajama.app.version_and_hash())
    ctx.exit()


def get_prog_name():

	return 'pajama'


@click.group(
	name=get_prog_name(), # When invoked by CliRunner, this name is used. 
	context_settings={
		'terminal_width': 80, # Ensure help text is consistently formatted.
		'auto_envvar_prefix': 'PAJAMA', # Use PAJAMA_* variables as defaults for options.
	}) 
@click.option(
	'--version', 
	is_flag=True, 
	callback=print_version,
	expose_value=False, 
	is_eager=True)
@click.pass_context
def cli(ctx):
	"""
	Pajama is an intuitive and performant build system. 

	Use `pajama <command> --help` to get help for a specific command.

	See also: http://joshcameron.github.io/pajama-docs
	"""
	#_ = ctx  # Unused

	# Set up the context object as a dictionary.
	ctx.ensure_object(dict)

	# Read environment variables from the project .env file (if any).

	root = pajama.project.find_root()

	if root:

		# Pajama was invoked from within a pajama project.

		project = pajama.project.Project(root)
		dotenv_environ = project.dotenv_environ()

		# Set environment variables from the project .env file.
		for key, value in dotenv_environ.items():

			os.environ[key] = value

		# Store the project in the context object for use by commands.
		ctx.obj['project'] = project

	# Set some default environment variables for the pajama build.
	#os.environ['PAJAMA_BUILD_BUILD_DIR'] = 'some-build-dir'
	#os.environ['PAJAMA_OPTION_FROM_DOTENV'] = 'value_from_dotenv'


@cli.command()
@click.option(
	'--clean', 
	is_flag=True, 
	help="Clean the build directory before building.")
@click.option(
	'--build-dir', 
    default=None,
    type=click.Path(file_okay=False, dir_okay=True, resolve_path=True),
	help="Directory in which to perform build. [default: <project-root>/build]")
@click.argument('target_name', nargs=1, required=False)
@click.pass_context
def build(ctx, clean, build_dir, target_name):
	"""
	Build the pajama project.
	"""

	if 'project' not in ctx.obj:

		click.echo("Error: Not in a pajama project directory.")
		ctx.exit(1)

	invoke(
        ctx.obj['project'].root,
		'build', 
		{
            'clean': clean, 
            'build_dir': build_dir,
        }, 
		{'target_name': target_name})


#@cli.command()
#def docs():
#	"""
#	One sentence help for docs.
#	Additional detail.
#	"""
#	print('docs')


if __name__ == "__main__":

	#print(f'> {" ".join(sys.argv)}')

	# Based on the location of the pajama executable, we find the built-in collection. 
	#pajama_dir = os.path.dirname(os.path.abspath(__file__))
	#pajama_collection_dir = os.path.join(pajama_dir, "collection")

	# Add the collection directory to the system path so we may import modules from the collection.
	# sys.path.clear()
	#sys.path.insert(0, pajama_collection_dir)

	cli(
		prog_name=get_prog_name(), 
	)

