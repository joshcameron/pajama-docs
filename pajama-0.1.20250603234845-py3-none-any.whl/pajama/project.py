import os

import tomllib

import dotenv


def find_root() -> str | None:
	"""
	Seek out the root directory of the build. Start from cwd and look upward
	until a directory containing a .pajama-project subdirectory is found.

	Returns:
			The path of the root directory, or None, if the working directory
			is not part of a pajama build.
	"""

	result = None
	path = os.getcwd()

	while True:

		pajama_dir_path = os.path.join(path, ".pajama-project")

		if os.path.isdir(pajama_dir_path):
			# We've found a directory containing a .pajama subdirectory.
			# This is a pajama project directory.
			result = path
			break

		path = os.path.dirname(path)

		if os.path.ismount(path):
			# We've reached the root of the filesystem without finding a
			# pajama project directory.
			break

	return result


class Project:
	"""
	Represents a pajama project.
	"""

	def __init__(self, root: str):
		"""
		Initialize the project with the given root directory.
		"""
		self.root = root
		self.dotenv_path = os.path.join(self.root, '.env')
		self.dotenv_local_path = os.path.join(self.root, '.env.local')
		self.config_path = os.path.join(self.root, '.pajama-project', 'config.toml')
		self.config_local_path = os.path.join(self.root, '.pajama-project', 'config.local.toml')


	def __repr__(self):
		return f"Project(root={self.root})"


	def load_dotenv(self, dotenv_path) -> dict:
		"""
		Load the environment variables from the .env file in the project root directory.
		"""
		if os.path.isfile(dotenv_path):

			dotenv.load_dotenv(dotenv_path)

			return dotenv.dotenv_values(dotenv_path)

		else:

			return {}


	def dotenv_environ(self) -> dict:
		"""
		Load the environment variables from the .env file in the project root directory.
		"""
		return self.load_dotenv(self.dotenv_path)


	def dotenv_local_environ(self) -> dict:
		"""
		Load the environment variables from the .env file in the project root directory.
		"""
		return self.load_dotenv(self.dotenv_local_path)


	def load_config(self, config_path) -> dict:
		"""
		Load project configuration from the given config file.
		"""
		try: 

			with open(config_path, 'rb') as file:
				config = tomllib.load(file)
				return config

		except FileNotFoundError:

			return {}


	def config(self) -> dict:
		"""
		Load the project configuration from config.toml.
		"""
		return self.load_config(self.config_path)


	def config_local(self) -> dict:
		"""
		Load the project configuration from config.local.toml.
		"""
		return self.load_config(self.config_local_path)
