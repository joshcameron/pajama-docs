import pajama.artifact
import pajama.impl.cache as cache
import pajama.tool_artifact as tool_artifact


class ListOfToolArtifacts(pajama.artifact.ListOfArtifacts):

	def __init__(
			self, 
			tool_id=None, 
			cache_entry=None,
			requisite_operation_signature=None,
			requisite_output_name=None):

		super().__init__(cache_entry, requisite_operation_signature, requisite_output_name)

		if not cache_entry:

			self.tool_id = tool_id


	def init_from_cache(self, cache_entry):

		assert 'tool_id' in cache_entry

		self.tool_id = cache_entry['tool_id']
		super().init_from_cache(cache_entry)


	def __str__(self):

		artifact_strs = []

		for artifact in self.artifacts:

			artifact_strs.append(artifact.abs_path)

		artifacts_str = ','.join(artifact_strs)

		return f'tools [{artifacts_str}]'


	# TODO: Does tool_id actually need to be a property of this class?
	# This artifact class is probably unnecessary. It could simply be a list of artifacts.

	def signature_properties(self) -> dict:

		result = super().signature_properties()

		result['tool_id'] = self.tool_id

		return result


