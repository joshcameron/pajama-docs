import datetime
import os
import sys
import time
import traceback
import types
from pathlib import Path

from pajama import config, environment, log, project, version
from pajama.impl import build, exception, session


class Application:

	def __init__(
			self,
			exe_dir: Path,
			command: str, 
			options: dict, 
			args: dict,
			proj: project.Project,
			environ: environment.Environment,
			conf: config.Config):

		self.project = proj
		self.exe_dir = exe_dir
		self.command = command
		self.options = options
		self.args = args
		self.config = conf

		self.environment = environ
		self.environment.add_dotenv(self.project.dotenv_path)

		self.src_dir = self.project.root   

		# Pajama was invoked from within a pajama project.

		self.build_dir: Path | None = None
		self.inventory_dir = None
		self.collection_dirs = []
		self.build = None


	def configure(self):

		# Read command line options

		self.build_dir = self.project.root / "build"

		if self.command == 'build':

			if self.options['build.build_dir']:

				self.build_dir = Path(self.options['build.build_dir'])

				if not self.build_dir.is_dir():

					source = 'command line'
					raise exception.BuildDirectoryNotFound(self.build_dir, source)

			elif self.config['build.build_dir']:

				build_root = Path(self.config['build.build_dir']).expanduser().resolve()

				if not build_root.is_dir():

					#source = self.config.source()
					source = 'config file'
					raise exception.BuildRootDirectoryNotFound(build_root, source)

				self.build_dir = build_root / self.project.name

		#self.build_dir = f"/Users/joshcameron/Builds/{self.project.name}"
		self.inventory_dir = self.build_dir / ".pajama-inventory"

		# TODO: These should be configured by command line flag or config file.
		self.collection_dirs.append("/Users/joshcameron/Projects/pajama/src/collection")
		# TODO: For the time being, the default collection is integrated into
		# the built-in collection.
		# self.collection_dirs.append(
		# '/Users/joshcameron/Projects/default-pajama-collection')
		# self.collection_dirs.append(
		# '/Users/joshcameron/Projects/custom-pajama-collection')


	def perform_build(self):

		# pylint: disable=used-before-assignment
		self.build = build.Build(
			src_dir=self.src_dir,
			build_dir=self.build_dir,
			inventory_dir=self.inventory_dir,
			collection_dirs=self.collection_dirs)

		if self.options['build.clean']:

			self.build.clean_phase()

		self.build.inventory_phase()
		self.build.build_phase()
		self.build.summarize()
		self.build.check_integrity()


	def run(self):

		log.info(f"pajama {version.version_and_hash()}")

		self.restrict_environment()
		self.restrict_python_path()
		self.configure()
		self.perform_build()


	def restrict_environment(self):
		"""
		Restrict environment variables to only those defined in the
		environment files and the ones passed through from the command line.
		"""

		# Clear os.environ to avoid loading existing system environment variables
		os.environ.clear()
		os.environ.update(self.environment.as_dict())


	def restrict_python_path(self):

		"""
		Limit sys.path (ie PYTHONPATH) to only those modules installed in the
		python installation we are using (eg stuff in site_packages). This
		allows code to import standard Python modules, but reduces the risk of
		importing python modules we don't expect to import.
		"""

		# TODO allow the user to enable/disable this minimization using a
		# command line flag.

		# TODO allow the user to explicitly add to the PYTHONPATH using a
		# command line flag. This allows the user to import from directories
		# other than the site_packages of the Python executable, but also
		# allows us to track what python modules are available and whether
		# they have changed since the previous build.

		# TODO TEST that we have not introduced any dependencies on packages
		# which don't exist in a standard Python distribution. Or TEST that
		# we only depend on packages which are in the standard Python
		# distribution or part of an explicit list we require when pajama is
		# installed.

		restricted_sys_path = []

		# We want to keep in sys.path the directories which are part of the
		# Python installation, so code can import standard Python modules.

		python_bin_dir = os.path.dirname(os.path.realpath(sys.executable))
		python_install_dir = os.path.dirname(python_bin_dir)

		for path in sys.path:

			if path.startswith(python_install_dir):

				restricted_sys_path.append(path)

		# Add pajama's built-in collection directory to sys.path.
		pajama_collection_dir = self.exe_dir.parent / 'collection'
		restricted_sys_path.append(str(pajama_collection_dir))
		pajama_src_dir = self.exe_dir.parent
		restricted_sys_path.append(str(pajama_src_dir))

		sys.path = restricted_sys_path

		# TODO tag this output
		log.debug("restrict_python_path setting sys.path to: {str(sys.path)}", tag="python")


def on_uncaught_exception(
		exception_type: type[BaseException],
		value: BaseException,
		tb: types.TracebackType | None):

	"""
	Handle uncaught exceptions by dropping into the debugger.

	Args:
		exception_type: The type of the exception.
		value: The exception object.
		tb: The traceback object.
	"""

	if hasattr(sys, 'ps1') or not sys.stderr.isatty():  # or exception_type is not AssertionError:

		print(f'hasattr(sys, "ps1")={hasattr(sys, "ps1")}')
		print(f'sys.stderr.isatty()={sys.stderr.isatty()}')
		print(f'exception_type={exception_type}')
		print('calling default uncaught exception handler')
		# We are in interactive mode or we don't have a tty-like
		# device, so we call the default uncaught exception handler.
		sys.__excepthook__(exception_type, value, tb)

	else:

		print('dropping into debugger due to uncaught exception')
		# We are NOT in interactive mode. Print the exception.
		traceback.print_exception(exception_type, value, tb)
		print()

		# Start the debugger in post-mortem mode.
		# pylint: disable=import-outside-toplevel 
		# ruff: noqa: T100
		import pdb
		pdb.pm()


def invoke(exe_dir: Path, command: str, options: dict, args: dict):

	# Register our custom uncaught exception handler.
	sys.excepthook = on_uncaught_exception

	try:

		session.begin()

		wall_clock_tick = time.perf_counter()

		project_root = project.find_root()

		if not project_root:

			raise exception.NotInPajamaProject(directory=project_root)


		proj = project.Project(project_root)
		environ = environment.Environment()
		conf = config.Config(proj)
		application = Application(exe_dir, command, options, args, proj, environ, conf)
		application.run()

		wall_clock_tock = time.perf_counter()
		wall_clock_duration = wall_clock_tock - wall_clock_tick

		log.info(f"Build duration: {wall_clock_duration}s", tag="stats")

		# Record a history of build times to file.
		# TODO This is useful, but we cannot let the file continue to grow
		# indefinitely.
		# TODO By default, we should not pollute the user's project directory with
		# this file.
		with open(".pajama-project/build-time.csv", "a", encoding="utf-8") as file:

			file.write(
				f"{datetime.datetime.now(datetime.timezone.utc).isoformat()}, "
				f"{wall_clock_duration}\n")

	except exception.PajamaException as pajama_exception:

		log.error(str(pajama_exception))
