import pajama.impl.clang

"""
This module declares no user facing functions. Invoke the clang compiler by using
`pajama.cpp.select_compiler('clang.cpp.compiler')` to select the clang compiler and using
`pajama.cpp.compile()` to compile.
"""
