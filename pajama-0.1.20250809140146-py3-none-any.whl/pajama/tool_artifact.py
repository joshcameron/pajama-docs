import importlib
import os
import sys

from pajama import artifact
from pajama.impl import convert, tool, tool_registry


class ToolArtifact(artifact.Artifact):

    def __init__(
            self,
            tool_id=None,
            _tool_cls=None,
            version_str=None,
            abs_path=None,
            cache_entry=None,
            requisite_operation_signature=None,
            requisite_output_name=None):

        self._tool_cls = None
        self.tool_cls_str = None
        self.tool_module = None

        #if cache_entry:
        #   log.warning(f'ToolArtifact.__init__(cache_entry={cache_entry}')
        #else:
        #   log.warning(f'ToolArtifact.__init__: {tool_id} {version_str} ({id(self)})')
        #log.debug_stack()

        if not cache_entry:

            assert tool_id is not None
            assert isinstance(tool_id, str)

            self.tool_id = tool_id

            _tool_cls = tool_registry.get_tool_cls(tool_id)

            if _tool_cls is not None:
                self.tool_cls = _tool_cls
            self.version_str = version_str
            self.abs_path = abs_path

        super().__init__(cache_entry, requisite_operation_signature, requisite_output_name)

        #log.warning(f'ToolArtifact initialized with {self.tool_id} {self.version_str} ({id(self)})')

    def init_from_cache(self, cache_entry):

        super().init_from_cache(cache_entry)

        self.tool_id = cache_entry['tool_id']

        #log.debug_stack()
        #log.debug(f'ToolArtifact.init_from_cache: {self.tool_id} ({id(self)})')

        assert self.tool_id is not None

        self.version_str = cache_entry['version_str']
        self.abs_path = cache_entry['abs_path']
        assert self.abs_path
        self.tool_module = cache_entry['tool_module']

        if self.tool_module not in sys.modules:

            # Tools register themselves when they are first imported. Typically this happens
            # because code in a .pajama file imports the tool module prior to using any functions
            # related to the tool.
            #
            # When we load an include operation from cache, we can easily end up in a situation
            # where the tool module has not been imported yet, and therefore the tool does not
            # exist in the tool registry. So here we will import the module, causing the tool to
            # be registered, and then we can look it up.
            importlib.import_module(self.tool_module)

        _tool_cls = tool_registry.get_tool_cls(self.tool_id)
        assert isinstance(_tool_cls, type(tool.Tool))
        self.tool_cls = _tool_cls
        #log.warning(f'ToolArtifact.init_from_cache: {self.tool_id} {self.version_str} id: {id(self)}')

    def __str__(self):

        if self._tool_cls and self.version_str:

            return f'{self.tool_id} {self.version_str}'

        else:

            return f'unresolved tool ({self.tool_id})'

    # TODO use tool id to look up Tool code?
    @property
    def tool_cls(self):

        #log.debug(f'ToolArtifact.tool_cls() tool_id: {self.tool_id} {self.version_str} ({id(self)})')
        # Get the artifact's tool
        assert self._tool_cls is not None
        return self._tool_cls

    @tool_cls.setter
    def tool_cls(self, _tool_cls):

        #log.debug_stack()
        #log.debug(f'ToolArtifact.tool_cls.setter: {self.tool_id} {_tool_cls} ({id(self)})')
        assert isinstance(_tool_cls, type(tool.Tool)), \
            f'{_tool_cls} is actually a {type(_tool_cls)}'

        self._tool_cls = _tool_cls
        self.tool_cls_str = convert.cls_to_cls_str(self._tool_cls)
        self.tool_module = convert.cls_to_module_str(self._tool_cls)

    @property
    def version(self):

        assert self._tool_cls is not None
        return self._tool_cls.version_from_str(self.version_str)

    def signature_properties(self) -> dict:

        result = super().signature_properties()

        assert self.tool_id
        assert isinstance(self.tool_id, str)

        result['tool_id'] = self.tool_id
        result['tool_cls'] = convert.cls_to_cls_str(self.tool_cls)
        result['tool_module'] = self.tool_module
        result['version_str'] = self.version_str

        return result

    def value_properties(self) -> dict:

        result = super().value_properties()

        assert \
            self.abs_path, \
            f'No abs_path for ToolArtifact {self.tool_id} {self.version_str} ({id(self)})'

        result['abs_path'] = self.abs_path  # TODO Maybe should not be part of the signature?

        return result

    def has_filesystem_counterpart(self) -> bool:

        assert self.abs_path

        return self.abs_path is not None

    def filesystem_counterpart_exists(self) -> bool:

        return os.path.isfile(self.abs_path)

    def filesystem_counterpart_has_changed(self) -> bool:

        # TODO implement this. Also need to consider a tool may consist of
        # multiple files. We would need to check if any of them had changed.
        return False
        # raise NotImplementedError
