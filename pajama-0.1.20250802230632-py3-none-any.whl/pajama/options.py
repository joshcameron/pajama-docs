#from pajama import log
from pajama.impl import singleton


def set(name, value):

    #log.debug(f'options.set({name}, {value})')
    Options.instance().set(name, value)


def get(name):

    #log.debug(f'options.get({name})')
    return Options.instance().get(name)


class Option:

    def __init__(self, name, default_value):

        self.name = name
        self.default_value = default_value
        self.value = default_value

    """
    @property
    def name(self):

        return self._name

    @property
    def value(self):

        return self._value

    @value.setter
    def value(self, value):

        self._value = value

    @property
    def default_value(self):

        return self._default_value

    @property
    def is_default(self):

        return self._value == self._default_value

    @property
    def is_not_default(self):

        return self._value != self._default_value

    def reset(self):

        self._value = self._default_value

    def __str__(self):

        return f'{self._name}={self._value}'
    """


class Options(metaclass=singleton.Singleton):

    def __init__(self):

        self.options = {}

    def set(self, name, value):

        if name not in self.options:

            self.options[name] = Option(name, value)

        else:

            self.options[name].value = value

    def get(self, name):

        if name not in self.options:

            return None

        return self.options[name].value
