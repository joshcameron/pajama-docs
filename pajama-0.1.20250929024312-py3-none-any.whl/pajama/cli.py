#!/usr/bin/env python3
"""
Parses the pajama command line and invokes the pajama application.
Environment variables of the form "PAJAMA_<command>_<option>" -- if they exist -- are used to set 
default values for options.
This code is only concerned with parsing, and is not concerned with making appropriate decisions
based on the commands, options or arguments specified by the user.
"""

import json
import os
import sys
from pathlib import Path

import click
from pajama import app, version
from pajama.impl import analytics


def invoke(command: str, options: dict[str, str], args: dict[str, str]):
    """
    Invoke a command with the given options and arguments.

    Args:
            command: The command to invoke.
            options: A dictionary of options for the command.
            args: A dictionary of arguments for the command.
    """
    exe_dir = Path(os.path.dirname(os.path.abspath(__file__)))

    if "PAJAMA_DEV_TEST_CLI" in os.environ:

        json.dump(
            {
                "exe_dir": str(exe_dir), "command": command, "options": options, "args": args
            },
            sys.stdout,
            indent=4)

    else:

        analytics.track(command)
        app.invoke(exe_dir, command, options, args)


def print_version(ctx: click.Context, param: click.Parameter, value: bool):
    """
    Prints the version and hash of the Pajama application and exits.

    Args:
        ctx (click.Context): The Click context object.
        param (click.Parameter): The parameter triggering the callback (unused).
        value (bool): The value of the '--version' flag.
    """
    _ = param  # Unused

    if not value or ctx.resilient_parsing:

        return

    click.echo(version.version_and_hash())
    ctx.exit()


def get_prog_name():
    """
    Retrieves the program name for the CLI.

    Returns:
        str: The name of the program.
    """
    return "pajama"


@click.group(
    name=get_prog_name(),  # When invoked by CliRunner, this name is used.
    context_settings={
        "terminal_width": 80,  # Ensure help text is consistently formatted.
        "auto_envvar_prefix": "PAJAMA",  # Use PAJAMA_* variables as defaults for options.
    })
@click.option("--version", is_flag=True, callback=print_version, expose_value=False, is_eager=True)
@click.pass_context
def cli(ctx: click.Context):
    """
    Pajama is an intuitive and performant build system.

    Use `pajama <command> --help` to get help for a specific command.
    Options can also be set using environment variables of the form `PAJAMA_<command>_<option>`.

    See also: http://joshcameron.github.io/pajama-docs
    """

    # Set up the context object as a dictionary.
    _ = ctx.ensure_object(dict) # pyright: ignore[reportUnknownVariableType]


@cli.command()
@click.option("--clean", is_flag=True, help="Clean the build directory before building.")
@click.option(
    "--build-dir",
    default=None,
    type=click.Path(file_okay=False, dir_okay=True, resolve_path=True),
    help="Directory in which to perform build. [default: <project-root>/build]")
@click.argument("target_name", nargs=1, required=False)
@click.pass_context
def build(ctx: click.Context, clean: str, build_dir: str, target_name: str):
    """
    Build the pajama project.

    See also: http://joshcameron.github.io/pajama-docs
    """
    _ = ctx  # Unused

    command = "build"
    options = {
        "build.clean": clean,
        "build.build_dir": build_dir,
    }
    args = {"target_name": target_name}

    invoke(command, options, args)


#@cli.command()
#def docs():
#   """
#   One sentence help for docs.
#   Additional detail.
#   """
#   print('docs')

if __name__ == "__main__":

    #print(f'> {" ".join(sys.argv)}')

    # Based on the location of the pajama executable, we find the built-in collection.
    #pajama_dir = os.path.dirname(os.path.abspath(__file__))
    #pajama_collection_dir = os.path.join(pajama_dir, "collection")

    # Add the collection directory to the system path so we may import modules from the collection.
    # sys.path.clear()
    #sys.path.insert(0, pajama_collection_dir)

    cli(prog_name=get_prog_name()) # pylint: disable=no-value-for-parameter
