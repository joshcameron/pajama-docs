"""
Settings store values to be used later in the build. 

Setting names and types are declared and registered by Pajama toolsets or by Pajama itself. 
There are two setting types: single-value settings, and dictionary settings. Single-value settings 
consist of a setting name and a value. Dictionary settings consist of a setting name and a 
dictionary of key-value pairs.

"""

import pajama.artifact
import pajama.impl.settings as impl
from pajama.impl import exception, tool_registry


def set_dictionary_setting(setting_name: str, *args):
    """
    Set a key-value pair in a dictionary setting.

    Args:
        setting_name: The name of the dictionary setting to set.
        args: The key and value to set. If a single argument of type `DictOfArtifacts` is provided,
            the entire dictionary will be replaced with the provided dictionary. If two arguments 
            are provided, the first is the key and the second is the value. If no value is provided, 
            the value will be `NoneArtifact`.
    """
    # The named setting is a dictionary of artifacts.

    if len(args) == 0:  # pyright: ignore  [reportUnknownArgumentType]

        raise TypeError("At least one argument is required.")

    if len(args) == 1 and isinstance(
            args[0],
            pajama.artifact.DictOfArtifacts):  # pyright: ignore [reportUnknownArgumentType]

        # We are setting the entire dictionary.
        impl.SettingsStack.instance().top.set_value(setting_name, args[0])

        return

    if len(args) > 2:

        raise AssertionError(f"Too many arguments: {len(args)}")

    # We are setting or updating a single item in the dictionary.
    # args[0] is the key, args[1] is the value (if present).

    if not isinstance(args[0], str):

        raise TypeError(f"Dictionary setting key must be a string. Received {type(args[0])}.")

    # TODO: replace key with canonical key? eg '--std' -> '-std'
    key: str = args[0]

    if len(args) == 1:  # pyright: ignore  [reportUnknownArgumentType]

        # We are putting an entry in the dictionary, but the entry
        # will have no value, only a key.

        artifact = pajama.artifact.NoneArtifact()

    elif len(args) == 2:  # pyright: ignore  [reportUnknownArgumentType]

        # We are putting an entry in the dictionary, with key and value.

        if not isinstance(args[1], (pajama.artifact.Artifact, str)):

            raise AssertionError(f"Expected str or Aritifact value. Value is a {type(args[1])}")

        # TODO: validate value here?

        if isinstance(args[1], pajama.artifact.Artifact):

            artifact: pajama.artifact.Artifact = args[1]

        else:

            artifact = pajama.artifact.StringArtifact(args[1])

    if key:

        impl.SettingsStack.instance().top.set_key_value_pair(setting_name, key, artifact)

    else:

        impl.SettingsStack.instance().top.set_value(setting_name, artifact)


def set(setting_name: str, *args):
    """
    Args:
        setting_name: The name of the setting to set.
        args: The value to set the setting to. For single-value settings, `args` is 
            `str | Artifact`. `str` values will automatically be converted to `StringArtifact`.
            For dictionary settings, `args` is typically `str` key and `str | Artifact` value. 
            Again, `str` values will automatically be converted to `StringArtifact`.
            Callers who need to set the entire dictionary at once can pass a `DictOfArtifacts`. 

    Raises:
        exception.UseOfUnregisteredSettingName: If the setting name is not registered.

    Example:
    ```python
        from pajama import artifact, settings

        file_artifact = artifact.FileArtifact('foo.c')

        # Set a single-value setting to an artifact value.
        settings.set('some_toolset.some_file', file_artifact)

        # Set a single-value setting to a string value.
        settings.set('some_toolset.some_string', 'hello')

        # Set dictionary settings to key-value pairs.
        settings.set('some_toolset.some_dict', 'key_name', file_artifact)
        settings.set('some_toolset.some_dict', 'another_key_name', 'a different value')
    ```
    """

    # TODO document how to get a list of all valid setting names.
    # TODO This takes arguments, converts them to artifacts
    # TODO If we call a validate_fn to validate the arguments, there is a
    # problem when the setting is a DictOfArtifacts. We would need to
    # pass the dictionary artifact to the validate_fn so it could fill in new
    # entries appropriately. Or we would need validate_fn to reply with
    # something describing the edits we need to do (complicated).

    # Ensure the tool is registered, by importing it if necessary.
    tool_id = setting_name.split(".")[0]
    tool_registry.import_tool(tool_id)

    if setting_name not in impl.SpecRegistry.instance().setting_specs:

        raise exception.UseOfUnregisteredSettingName(setting_name)

    setting_spec = impl.SpecRegistry.instance().setting_specs[setting_name]

    if setting_spec.accepted_types == [pajama.artifact.DictOfArtifacts]:

        set_dictionary_setting(setting_name, *args)  # pyright: ignore  [reportUnknownArgumentType]

    else:

        assert len(args) == 1

        value: pajama.artifact.Artifact | str = args[0]
        # TODO assert setting expects a single value
        # TODO validate value?

        if isinstance(value, pajama.artifact.Artifact):
            artifact = value

        elif isinstance(value, str):
            artifact = pajama.artifact.StringArtifact(value)

        else:
            raise AssertionError()

        impl.SettingsStack.instance().top.set_value(setting_name, artifact)


def get(setting_name: str) -> pajama.artifact.Artifact:
    """
    Get the value of the named setting.

    Args:
        setting_name: The name of the setting to get. Use of an unregistered setting name will 
            raise an exception.

    Returns:
        The value of the setting.

    Raises:
        exception.UseOfUnregisteredSettingName: If the setting name is not registered.

    """

    if setting_name not in impl.SpecRegistry.instance().setting_specs:

        raise exception.UseOfUnregisteredSettingName(setting_name)

    return impl.SettingsStack.instance().top.get(setting_name)


def contains(setting_name: str) -> bool:
    """
    Check if a setting with the specified name is in the current settings.

    Args:
        setting_name: The name of the setting to check.

    Returns:
        True if a setting with the specified name is in the current settings.
    """
    return impl.SettingsStack.instance().top.contains(setting_name)
