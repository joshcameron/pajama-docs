import traceback

import pajama.impl.log as impl


def debug(message: str, tag: str = "untagged", stacklevel: int = 3):
    """
    Log a debug message. Debug messages are prefaced with the file and line number where this
    function was called.

    Args:
        message: The message to log.
        tag: A string that can be used to filter log messages.
        stacklevel: The number of stack frames to skip when determining the \
            location of the log message. The default value of 3 is usually \
            appropriate.

    Example:
    ```python
    some_string = 'hello'
    log.debug(f'some_string is {some_string}')
    # DEBUG filename.py:123 : [untagged] some_string is hello
    ```
    """

    impl.Logger.instance().debug(str(message), tag=tag, stacklevel=stacklevel)


def debug_stack(tag: str = "untagged", stacklevel: int = 3):
    """
    Log the current stack trace.

    Args:
        tag: A string that can be used to filter log messages.
        stacklevel: The number of stack frames to skip when determining the \
            location of the log message. The default value of 3 is usually \
            appropriate.
    """

    # Log the current stack trace. Useful to know what execution path has
    # led you to a problem.

    formatted_stack = traceback.format_stack()

    # Our printable stack summary will be the formatted stack except the last
    # stack entry, which is always the call to traceback.format_stack() above.
    stack_summary = "".join(formatted_stack[:-1])

    impl.Logger.instance().debug(f"Current stack:\n{stack_summary}", tag, stacklevel=stacklevel)


def verbose_debug(message: str, tag: str = "untagged", stacklevel: int = 3):
    """
    Log a verbose debug message. A verbose debug message provides additional detail, and \
    is only logged if the verbose flag is set.

    Args:
        message: The message to log.
        tag: A string that can be used to filter log messages.
        stacklevel: The number of stack frames to skip when determining the \
            location of the log message. The default value of 3 is usually \
            appropriate.
    """

    impl.Logger.instance().debug(str(message), tag=tag, stacklevel=stacklevel, verbose=True)


def info(message: str, tag: str = "untagged", stacklevel: int = 3):
    """
    Log an informational message.

    Args:
        message: The message to log.
        tag: A string that can be used to filter log messages.
        stacklevel: The number of stack frames to skip when determining the \
            location of the log message. The default value of 3 is usually \
            appropriate.
    """

    impl.Logger.instance().info(str(message), tag=tag, stacklevel=stacklevel)


def warning(message: str, tag: str = "untagged", stacklevel: int = 3):
    """
    Log a warning message.

    Args:
        message: The message to log.
        tag: A string that can be used to filter log messages.
        stacklevel: The number of stack frames to skip when determining the \
            location of the log message. The default value of 3 is usually \
            appropriate.
    """

    impl.Logger.instance().warning(str(message), tag=tag, stacklevel=stacklevel)


def error(message: str, tag: str = "untagged", stacklevel: int = 3):
    """
    Log an error message.

    Args:
        message: The message to log.
        tag: A string that can be used to filter log messages.
        stacklevel: The number of stack frames to skip when determining the \
            location of the log message. The default value of 3 is usually \
            appropriate.
    """

    impl.Logger.instance().error(str(message), tag=tag, stacklevel=stacklevel)


def critical(message: str, tag: str = "untagged", stacklevel: int = 3):
    """
    Log a critical error message.

    Args:
        message: The message to log.
        tag: A string that can be used to filter log messages.
        stacklevel: The number of stack frames to skip when determining the \
            location of the log message. The default value of 3 is usually \
            appropriate.
    """

    impl.Logger.instance().critical(str(message), tag=tag, stacklevel=stacklevel)
