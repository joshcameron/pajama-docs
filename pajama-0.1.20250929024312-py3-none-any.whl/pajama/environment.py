"""
The environment in which the build is executed.
"""
import os
from pathlib import Path

import dotenv


class Variable:
    """
    Represents an environment variable.
    """

    def __init__(self, name: str, value: str, source: str):
        """
        Initialize the variable with a name and value.

        Args:
            name (str): The name of the variable.
            value (str): The value of the variable.
            source (str): Source of the variable (e.g., dotenv file).
        """
        self.name = name
        self.value = value
        self.source = source


class Environment:

    def __init__(self):
        """
        Initialize the environment.
        """

        self.original_environ = os.environ.copy()
        self.variables = {}

        # Add any environment variables that start with 'PAJAMA_' from the original environment.
        for name, value in self.original_environ.items():

            if name.startswith("PAJAMA_"):

                self.variables[name] = Variable(name, value, "shell")

        # Start with an empty environment and only add variables that are explicitly set/approved.
        os.environ.clear()
        os.environ.update(self.as_dict())

    def add_dotenv(self, dotenv_path: Path):
        """
        Add environment variables from a .env file to the current environment.
        Overwrite existing environment variables with the same name.

        Args:
            dotenv_path (Path): Path to the .env file.
        """
        environ = self.load_dotenv(dotenv_path)

        # Add the loaded environment variables to the current environment, overwriting any
        # existing ones with the same name.
        for name, value in environ.items():

            # If the variable is already in the environment, it will be overwritten.
            # TODO: Warn about conflicts? Unless the warning is suppressed?
            self.variables[name] = Variable(name, value, str(dotenv_path))

        os.environ.update(self.as_dict())

    def add_pass_through_vars(self, pass_through_vars: list[str], source: str):
        """
        Add environment variables to the current environment that should be passed through.

        Args:
            pass_through_vars (list[str]): List of environment variable names to pass through.
            source (str): Source of the list of variables (e.g., config file).
        """
        for name in pass_through_vars:

            if name in self.original_environ:

                self.variables[name] = Variable(name, self.original_environ[name], source)

        os.environ.update(self.as_dict())

    def __getitem__(self, name: str) -> str:
        """
        Get an environment variable value by name. Enables dictionary-like access.

        Example: 
            value = env['MY_VARIABLE']
        """
        return self.variables[name].value

    def as_dict(self) -> dict:
        """
        Return the environment variables as a dictionary.
        """
        return {name: var.value for name, var in self.variables.items()}

    def load_dotenv(self, dotenv_path: Path) -> dict:
        """
        Load the environment variables from the specified .env file.
        """
        if dotenv_path.is_file():

            dotenv.load_dotenv(dotenv_path)

            return dotenv.dotenv_values(dotenv_path)

        else:

            return {}
