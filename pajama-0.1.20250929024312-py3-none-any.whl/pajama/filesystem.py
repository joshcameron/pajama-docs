"""
Implements typical filesystem functionality, such as copying files and directories.
"""

import os

from pajama import artifact, log, settings
from pajama.impl import exception, filesystem


# TODO default dst_dir to current build directory
# or TODO rename this to copy_file_to_dir(), and add a copy_file() function which copies within
# the same directory.
def copy_file(
        src_file: artifact.FileArtifact | str,
        dst_dir: artifact.DirectoryArtifact | artifact.StringArtifact | str,
        new_file_name: str | None = None):
    """
    Copy a file.

    Copy the specified file to the specified directory. The copy can be given a new name.

    Args:
        src_file: Source file path (absolute, or relative to setting `build.current_src_dir`).
        dst_dir: Destination directory path (absolute, or relative to setting `build.current_build_dir`).
        new_file_name: (Optional) New name for the copied file.

    """

    # TODO To make it clearer to the caller, some validation should be done
    # here.

    exception.type_check("src_file", src_file, (artifact.FileArtifact, str))
    # TODO Be stricter? Disallow use of StringArtifact?
    exception.type_check(
        "dst_dir", dst_dir, (artifact.DirectoryArtifact, artifact.StringArtifact, str))
    exception.type_check("new_file_name", new_file_name, (str, type(None)))

    input_artifacts = {}

    if isinstance(src_file, artifact.FileArtifact):

        input_artifacts["src_file"] = src_file

    elif isinstance(src_file, str):

        input_artifacts["src_file"] = artifact.FileArtifact(os.path.abspath(src_file))

    if new_file_name:

        # The file is to be renamed as it is copied.
        input_artifacts["dst_file_name"] = artifact.StringArtifact(new_file_name)

    else:

        # The copied file should have the same name as the source file.
        input_artifacts["dst_file_name"] = artifact.StringArtifact(
            os.path.basename(input_artifacts["src_file"].abs_path))

    if isinstance(dst_dir, artifact.DirectoryArtifact):

        input_artifacts["dst_dir"] = dst_dir

    elif isinstance(dst_dir, artifact.StringArtifact):

        # TODO This breaks the dependency between the StringArtifact and the DirectoryArtifact.
        # I think that's a problem. I think if a StringArtifact is used, it needs to be passed
        # along. Otherwise, the value of the StringArtifact could be changed, and the operation
        # would not be re-executed, because the DirectoryArtifact is cached and unchanged.
        # Furthermore, we need to distinguish between two StringArtifacts with the same value.
        # Otherwise the user could change the value of the one they've used for this call, but the
        # duplicate would still exist in the cache, and we'd use the duplicate, not knowing we're
        # using the wrong one.
        input_artifacts["dst_dir"] = artifact.DirectoryArtifact(dst_dir.value)

    else:

        input_artifacts["dst_dir"] = artifact.DirectoryArtifact(dst_dir)

    action = filesystem.CopyFileAction(input_artifacts)

    return action.output_artifacts["dst_file"]


def copy_dir(
        src_dir: artifact.DirectoryTreeArtifact | str, dst_dir: artifact.DirectoryArtifact | str):
    """
    Copy a directory.

    Recursively copy the specified directory to the specified destination directory.

    Args:
        src_dir: The source directory. If `str`, `src_dir` can be an absolute path or a path 
            relative to setting `build.current_src_dir`.
        dst_dir: The destination directory. If `str`, `dst_dir` must be a path relative to setting
            `build.current_build_dir`. 

    Example:
    ```python
        >>> some_string = 'hello'
        >>> len(some_string)
        5
    ```
    """

    exception.type_check("src_dir", src_dir, (artifact.DirectoryTreeArtifact, str))
    exception.type_check("dst_dir", dst_dir, (artifact.DirectoryArtifact, str))

    input_artifacts = {}

    # src can be a DirectoryTreeArtifact (contains an abs_path), or a str
    # containing an absolute path, or a str containing a path relative to
    # build.current_src_dir.

    if isinstance(src_dir, artifact.DirectoryTreeArtifact):

        input_artifacts["src_dir"] = src_dir

    elif isinstance(src_dir, str):

        # If the source dir is specified as a string, we insist the dir
        # must already exist. For dirs which do not yet exist, the caller
        # must specify the source dir as a DirectoryTreeArtifact (generated
        # by some other action).

        # TODO What if the user has a DirectoryArtifact instead of a DirectoryTreeArtifact?

        if os.path.isdir(src_dir):

            # The src_dir is an absolute path to an existing directory.
            abs_path = src_dir

        else:

            # TODO: rel_path and build.current_src_dir should be input artifacts.
            # The src_dir is a relative path to an existing directory under build.current_src_dir.
            abs_path = os.path.normpath(
                os.path.join(settings.get("build.current_src_dir").abs_path, src_dir))

            assert os.path.isdir(abs_path)

        input_artifacts["src_dir"] = artifact.DirectoryTreeArtifact(abs_path)

    else:

        raise TypeError

    abs_path = ""

    if isinstance(dst_dir, artifact.DirectoryArtifact):

        input_artifacts["dst_dir"] = dst_dir

    elif isinstance(dst_dir, str):

        # TODO: Danger: we should not use the setting directly. We should use the input artifact
        # obtained because the setting is a relevant setting.
        abs_path = os.path.normpath(
            os.path.join(settings.get("build.current_build_dir").abs_path, dst_dir))

        input_artifacts["dst_dir"] = artifact.DirectoryArtifact(abs_path)

    else:

        raise TypeError

    action = filesystem.CopyDirAction(input_artifacts)

    assert isinstance(action.output_artifacts["dst_dir"], artifact.DirectoryTreeArtifact)

    log.debug(f'copy dir output DirectoryTreeArtifact is {action.output_artifacts["dst_dir"]}')

    return action.output_artifacts["dst_dir"]


def make_directory(rel_path: str):
    """
    Make a directory, and any necessary non-existent parent directories.

    Args:
        rel_path: The path of the directory to be created, relative to the current build directory.
    """

    exception.type_check("rel_path", rel_path, (str))

    input_artifacts = {}

    # TODO: rel_path and build.current_src_dir should be input artifacts.

    abs_path = os.path.normpath(
        os.path.join(settings.get("build.current_build_dir").abs_path, rel_path))
    input_artifacts["abs_path"] = artifact.DirectoryArtifact(abs_path)

    action = filesystem.MakeDirectoryAction(input_artifacts)

    directory_artifact = action.output_artifacts["directory"]
    log.debug(f"anticipated directory path: {directory_artifact.abs_path}", tag="filesystem")

    return directory_artifact
