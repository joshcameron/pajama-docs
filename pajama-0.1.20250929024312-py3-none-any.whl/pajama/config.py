from collections.abc import MutableMapping
from pathlib import Path

import tomllib
from pajama import project


def flatten(dictionary: dict, parent_key: str = "", separator: str = "."):

    items = []

    for key, value in dictionary.items():

        new_key = parent_key + separator + key if parent_key else key

        if isinstance(value, MutableMapping):

            items.extend(flatten(value, new_key, separator=separator).items())

        else:

            items.append((new_key, value))

    return dict(items)


class Config:

    def __init__(self, project: project.Project):

        self.project = project

        self.project_config_path = self.project.project_dir / "config.toml"
        self.project_local_config_path = self.project.project_dir / "config.local.toml"
        self.user_config_path = Path.home() / ".config" / "pajama" / "config.toml"

        self.project_config = flatten(self.load_config(self.project_config_path))
        self.project_local_config = flatten(self.load_config(self.project_local_config_path))
        self.user_config = flatten(self.load_config(self.user_config_path))

    def load_config(self, config_path: Path) -> dict | None:
        """
        Load the configuration from a TOML file.

        Args:
            config_path: The path to the configuration file.
        """

        if config_path.exists():

            with config_path.open("rb") as file:

                config = tomllib.load(file)

                return config

        return {}

    def __getitem__(self, key: str):
        """
        Get a configuration value by key.

        Args:
            key: The key to retrieve the configuration value for.
        """

        if self.project_config and key in self.project_config:
            return self.project_config[key]

        if self.project_local_config and key in self.project_local_config:
            return self.project_local_config[key]

        if self.user_config and key in self.user_config:
            return self.user_config[key]

        raise KeyError()

    def source(self, key: str):

        if self.project_config and key in self.project_config:
            return self.project_config_path

        if self.project_local_config and key in self.project_local_config:
            return self.project_local_config_path

        if self.user_config and key in self.user_config:
            return self.user_config_path

        raise KeyError()
