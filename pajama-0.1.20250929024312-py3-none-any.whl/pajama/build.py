from pajama.impl import build


def include(directory_name):
    """
    Include the specified directory (which means look for a .pajama file in
    it).

    Args: 
        directory_name (str): The name of the directory to include.
    """

    build.include(directory_name)
