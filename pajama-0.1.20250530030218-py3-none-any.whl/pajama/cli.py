#!/usr/bin/env python3

"""
The executable invoked when a user types 'pajama' on the command line.
"""

import json
import os
import sys
from pathlib import Path

import click

import pajama.app

# It is responsible for:
# - Defining, parsing and validating command line options.
# - Limiting the system path.
# - Finding the appropriate top level .pajama file to include.
# - Instantiating the build and including the top level .pajama file.

g_test_mode = False

def enable_test_mode():
	"""
	Put the command line parser in test mode.
	Instead of invoking the application after parsing the command line, the CLI will print the 
	results of command line parsing in JSON format to stdout.
	"""
	#print(f'set_test_mode() called with test_mode={test_mode}')

	global g_test_mode
	g_test_mode = True


def invoke(command: str, options: dict, args: dict):
	"""
	Invoke a command with the given options and arguments.

	Args:
			command: The command to invoke.
			options: A dictionary of options for the command.
			args: A dictionary of arguments for the command.
	"""
	#print(f'invoke() called with command={command}, options={options}, args={args}')
	pajama_dir = Path(os.path.dirname(os.path.abspath(__file__)))

	if g_test_mode:

		json.dump(
			{
				'pajama_dir': str(pajama_dir),
				'command': command,
				'options': options,
				'args': args
			},
			sys.stdout, 
			indent=4)

	else:

		pajama.app.invoke(pajama_dir, command, options, args)


# Parse command line arguments. What target? What
# variant(s)/option(s)? Actually perform build? Or determine what
# would be built? Or produce a diagram of the build?
# Use a command structure like git, brew, etc? Commands could be like:
# > pajama
# > pajama some-target
# > pajama build
# > pajama build some-target
# > pajama build --options debug
# > pajama --graph some-target
# > pajama --graph
# > pajama build --dryrun
# > pajama build --dryrun some-target
# > pajama build --dryrun --options debug
# > pajama build --discover-only

def print_version(ctx, param, value):

    if not value or ctx.resilient_parsing:

        return

    click.echo(pajama.app.version_and_hash())
    ctx.exit()

def get_prog_name():

	return 'pajama'


@click.group(name=get_prog_name()) # When invoked by CliRunner, this name is used. 
@click.option(
	'--version', 
	is_flag=True, 
	callback=print_version,
	expose_value=False, 
	is_eager=True)
@click.pass_context
def cli(ctx, is_test=False):
	"""
	Pajama is an intuitive and performant build system. 

	Use `pajama <command> --help` to get help for a specific command.

	See also: http://joshcameron.github.io/pajama-docs
	"""
	#print('cli() called')
	pass


@cli.command()
@click.option(
	'--clean', 
	is_flag=True, 
	help="Clean the build directory before building")
@click.argument('target_name', nargs=1, required=False)
@click.pass_context
def build(ctx, clean, target_name):
	"""
	Build the pajama project.
	"""
	#print('build() called')
	#print(f'build clean={clean}, target_name={target_name}')
	invoke(
		'build', 
		{'clean': clean}, 
		{'target_name': target_name})


#@cli.command()
#@click.argument('command', nargs=1, required=False)
#@click.pass_context
#def help(ctx, command): # noqa: A001
#	"""
#	Use `pajama help <command>` to get help for a specific command.
#	"""
#	#print('help() called')
#	print(f'help command={command}')
#	command_obj = cli.get_command(ctx, command)
#	if command_obj:
#		ctx.info_name = command
#		click.echo(command_obj.get_help(ctx))
#	else:
#		click.echo(cli.get_help(ctx))


#@cli.command()
#def docs():
#	"""
#	One sentence help for docs.
#	Additional detail.
#	"""
#	print('docs')


if __name__ == "__main__":

	#print(f'> {" ".join(sys.argv)}')

	# Based on the location of the pajama executable, we find the built-in collection. 
	#pajama_dir = os.path.dirname(os.path.abspath(__file__))
	#pajama_collection_dir = os.path.join(pajama_dir, "collection")

	# Add the collection directory to the system path so we may import modules from the collection.
	# sys.path.clear()
	#sys.path.insert(0, pajama_collection_dir)

	cli(prog_name='pajama', auto_envvar_prefix='PAJAMA')

