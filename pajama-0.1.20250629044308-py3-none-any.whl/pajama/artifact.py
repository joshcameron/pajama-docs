"""
Defines all possible types of inputs and outputs of build actions.
"""

import datetime
import os
import traceback
from hashlib import md5

#import pajama.impl.operation
import pajama.impl.version
from pajama import log
from pajama.impl import cache, convert, file_and_line, post_init_caller, singleton

# TODO Is there a way to have the parent class do more of the work required to assemble
# signature/value/information property dicts? Ideally, the derived class should just have to 
# return a dict of things it needs in its own cache record. The parent class would ideally be
# responsible for adding its own and would also take care of ensuring there are no key conflicts.

def dummy_add_operation_fn(operation):
	"""
	Dummy function used to initialize Action.add_operation_fn. 
	Should never be executed.
	"""

	_ = operation # Unused

	raise NotImplementedError


class Artifact(cache.CacheableEntity, metaclass=post_init_caller.PostInitCaller):

	"""
	An artifact represents anything which, if modified since the previous build, or non-existent, would require a build
	action to be performed in the next build. The outputs of a build action are also artifacts.
	"""

	add_operation_fn = dummy_add_operation_fn
	""" Stores the function to add the operation to the current operation graph. """

	instance_records : dict = {}


	def __init__(
            self, 
            cache_entry=None, 
            requisite_operation=None, 
            requisite_output_name=None):

		"""
		Initialize the artifact, using the properties in cache_entry if specified.

		Args:
			cache_entry: A dict containing the properties of the artifact, if it is being loaded 
			from cache. Otherwise None.
		"""

		if requisite_operation:

			assert requisite_output_name

		Artifact.instance_records[id(self)] = {
			'str': self.__class__.__name__,
			'__init__': ''.join(traceback.format_stack())
		}

		super().__init__(cache_entry)
		self.requisite_operation: pajama.impl.operation.Operation | None = requisite_operation
		self.requisite_operation_signature: str | None = None
		self.requisite_output_name: str | None = None

		if requisite_operation:

			self.requisite_operation_signature = requisite_operation.cache_signature
			self.requisite_output_name = requisite_output_name

		self.dependent_operations: list[pajama.impl.operation.Operation] = []
		self.dependent_artifacts: list[Artifact] = []
		self.is_resolved = False  # is ready to be used by dependent operations
		self.name: str | None = None
		self.include_operation = None
		self.file_and_line = None

		if cache_entry:

			assert self.cache_entry

			self.init_from_cache(cache_entry)
			self.was_loaded_from_cache = True

		else:

			from pajama.impl import settings  # pylint: disable=import-outside-toplevel
			self.file_and_line = file_and_line.get()
			self.include_operation = settings.include_operation()

		# TODO Do we do this if the artifact is being created from cache_entry?
		# Add to the artifacts of the current include operation
		#include_operation = settings.include_operation()


    # TODO: Not sure this is useful.
	def __del__(self):

		#log.warning(f'Artifact.__del__ {self}', tag='artifact')
		Artifact.instance_records[id(self)]['__del__'] = ''.join(traceback.format_stack())
		assert id(self) in Artifact.instance_records
		log.debug('foobar', tag='artifact')
		log.debug(f'__init__: {Artifact.instance_records[id(self)]["__init__"]}', tag='artifact')
		log.debug(f'__del__: {Artifact.instance_records[id(self)]["__del__"]}', tag='artifact')


	def __post_init__(self):

		if self.include_operation:

			self.include_operation.add_included_artifact(self)


	def pre_str(self):

		show_signature = False

		if show_signature:

			return f'{self.cache_signature} '

		return ''


	def post_str(self):

		show_artifact_id = False

		if show_artifact_id:

			return f' {id(self)} from {self.requisite_operation!s}'

		return ''


	def init_from_cache(self, cache_entry):
		"""
		Perform initialization of the artifact using the properties in cache_entry.

		Args:
			cache_entry: A dict containing the properties of the artifact.
		"""
		# TODO: assert self.cache_entry is not None
		# and initialize from self.cache_entry
		# ?

		if 'file_and_line' in cache_entry:

			self.file_and_line = file_and_line.FileAndLine(
				cache_entry['file_and_line']['abs_path'], 
				cache_entry['file_and_line']['line_number'])

		if 'name' in cache_entry:

			# This is a named artifact. Register it in the named artifact registry.
			add_named_artifact(self, cache_entry['name'])

		if 'include_operation' in cache_entry:

			self.include_operation = cache_entry['include_operation']

		if 'requisite_operation_signature' in cache_entry:

			self.requisite_operation_signature = cache_entry['requisite_operation_signature']

		if 'requisite_output_name' in cache_entry:

			self.requisite_output_name = cache_entry['requisite_output_name']


	def save_to_cache(self):

		# By default, saving an artifact to cache only requires a cache.put(self) call. However,
		# for subclass Artifacts which represent collections of other Artifacts, the subclass
		# should override this method to save the collection's Artifacts to cache as well.
		cache.put(self)


	def add_dependent_operation(self, dependent_operation): #: pajama.impl.operation.Operation):
		"""
		Let the artifact know of an operation which depends on it. Dependent operations need to be notified when the
		artifact is marked ready.

		Args:
			dependent_operation: The operation which depends on this artifact.
		"""

		assert isinstance(dependent_operation, pajama.impl.operation.Operation)

		if dependent_operation not in self.dependent_operations:

			self.dependent_operations.append(dependent_operation)


	def resolve(self):
		"""
		Called after the requisite operation successfully generates this artifact, or in situations 
		where the artifact has no requisite operation. This method notifies all dependent 
		operations this artifact is resolved (meaning it is ready for use).
		"""

		if not self.is_resolved:

			self.is_resolved = True

			log.debug(f'resolve {self.cache_signature} {self}', tag='artifact')

			if not self.was_loaded_from_cache:

				# This artifact was created from arguments, not loaded from
				# cache. We only put the artifact in the cache if it wasn't
				# already in the cache. We also only add it to the artifact
				# registry if it is newly created.
				register_artifact(self)

			# Notify all dependent operations this artifact is resolved
			for dependent_operation in self.dependent_operations:

				dependent_operation.on_input_resolved(self)

		else:

			log.debug(
				f'resolve {self.cache_signature} {self} (already resolved)', 
				tag='artifact')


	def has_filesystem_counterpart(self) -> bool:
		"""
		Whether the artifact has a counterpart in the filesystem. Only classes derived from
		FilesystemArtifact should have filesystem counterparts.

		Returns:
			True if the artifact has a counterpart in the filesystem, False otherwise.
		"""

		return False


	@property
	def cache_signature(self) -> str:

		if not self._cache_signature:

			if self.requisite_operation_signature and self.requisite_output_name:

				# Artifacts which are outputs of an operation have a signature based solely on the
				# signature of the requisite operation and the name of the output

				properties = {
					'requisite_operation_signature': self.requisite_operation_signature, 
					'requisite_output_name': self.requisite_output_name
				}

				self._cache_signature = cache.compute_signature(type(self), properties)

				#log.debug(
				#	f'cache signature for {self} is {self._cache_signature} ' \
				#	f'based on {properties}')

			else:

				return super().cache_signature

		return self._cache_signature


	def signature_properties(self) -> dict:
		"""
		Signature properties are properties of the artifact which must be the same since the
		previous build in order for the artifact to be considered the same artifact it was in the
		previous build. Signature properties, in combination, uniquely identify the artifact. An
		example would be the absolute path of a file.

		Returns:
			A dict of the signature properties of this artifact.
		"""

		result = super().signature_properties()
		result['type'] = str(self.__class__.__qualname__)
		result['cls'] = f'{self.__class__.__module__}.{self.__class__.__qualname__}'

		return result


	def value_properties(self) -> dict:
		"""
		Value properties are properties of the artifact which -- if different from one build to the
		next -- indicate the artifact may have changed since the previous build. Value properties
		are not used to uniquely identify the artifact. An example would be the timestamp of a
		file.

		Returns:
			A dict of the value properties of this artifact.
		"""

		result = super().value_properties()

		if self.name:

			result['name'] = self.name

		return result


	def info_properties(self) -> dict:
		"""
		Informational properties are properties of the artifact which neither help to uniquely
		identify the artifact, nor indicate whether it has changed since the previous build. An
		example would be the build file and line number which created the artifact.

		Returns:
			A dict of the informational properties of this artifact.
		"""

		result = super().info_properties()

		if self.file_and_line:

			result['file_and_line'] = self.file_and_line.as_dict()

		if self.requisite_operation_signature:

			result['requisite_operation_signature'] = self.requisite_operation_signature

		if self.requisite_output_name:

			result['requisite_output_name'] = self.requisite_output_name

		return result



class FilesystemArtifact(Artifact):

	def __init__(
			self, 
			abs_path=None,
            cache_entry=None, 
            requisite_operation=None, 
            requisite_output_name=None):

		self._last_modified_time = None

		super().__init__(cache_entry, requisite_operation, requisite_output_name)

		if not cache_entry:

			assert abs_path is not None

			if isinstance(abs_path, StringArtifact):

				self.abs_path = os.path.realpath(abs_path.value)

			else:

				self.abs_path = os.path.realpath(abs_path)


		# TODO Find a way to shorten paths in __str__() when they refer to an abs_path under 
		# build.build_dir or build.project_src_dir.
		# TODO this does not work because we store build.project_src_dir and
		# build.build_dir settings in... FilesystemArtifacts.
		# import pajama.settings as settings
		# self.project_src_rel_path = None
		# self.build_rel_path = None
		# project_src_dir = settings.get('build.project_src_dir')
		# assert project_src_dir is not None
		# build_dir = settings.get('build.build_dir')
		# assert build_dir is not None
		#
		# if self.abs_path.find(project_src_dir):
		# self.project_src_rel_path = self.abs_path[len(project_src_dir):]
		# log.debug(f'project_src_rel_path: {self.project_src_rel_path}')
		#
		# if self.abs_path.find(build_dir):
		# self.build_rel_path = self.abs_path[len(build_dir):]
		# log.debug(f'build_rel_path: {self.build_rel_path}')


	def init_from_cache(self, cache_entry):

		super().init_from_cache(cache_entry)

		self.abs_path = cache_entry['abs_path']


	@property
	def last_modified_time(self) -> str:

		if self._last_modified_time is None:

			assert self.abs_path is not None

			timestamp = os.path.getmtime(self.abs_path)
			self._last_modified_time = datetime.datetime.fromtimestamp(timestamp).isoformat()

		return self._last_modified_time


	def has_filesystem_counterpart(self) -> bool:

		return True


	def filesystem_counterpart_exists(self) -> bool:

		raise NotImplementedError


	def filesystem_counterpart_has_changed(self) -> bool:

		if self.cache_entry is None:

			return True

		return (self.last_modified_time > self.cache_entry['last_modified_time'])


	def signature_properties(self) -> dict:

		result = super().signature_properties()
		result['abs_path'] = self.abs_path

		return result



class FileArtifact(FilesystemArtifact):

	# TODO userdoc

	def __init__(
			self, 
			abs_path=None,
            cache_entry=None, 
            requisite_operation=None, 
            requisite_output_name=None):

		self._checksum = None

		super().__init__(abs_path, cache_entry, requisite_operation, requisite_output_name)


	def __str__(self):

		if hasattr(self, 'abs_path'):

			return f'{self.pre_str()}{self.abs_path}{self.post_str()}'

		return f'{self.pre_str()}incomplete FileArtifact {self.post_str()}'


	@property
	def checksum(self):

		# TODO This method consumes a lot of time in the profile. Optimize.

		# TODO Use last modified time to avoid recomputing the checksum of a
		# file which has not changed.

		if self._checksum is None:

			assert self.abs_path is not None

			if os.path.isfile(self.abs_path):

				# Ignore "probable use of insecure hash function"
				# ruff: noqa: S324
				md5_hash = md5()

				with open(self.abs_path, 'rb') as file:

					for chunk in iter(lambda: file.read(128 * md5_hash.block_size), b''):

						md5_hash.update(chunk)

				self._checksum = md5_hash.hexdigest()

		return self._checksum


	def filesystem_counterpart_exists(self) -> bool:

		if not os.path.isfile(self.abs_path):

			#log.debug(f'{self.abs_path} is not file')
			pass

		return os.path.isfile(self.abs_path)


	def filesystem_counterpart_has_changed(self) -> bool:

        #log.debug(f'{self.abs_path} last modified time: {self.last_modified_time}')
        #log.debug(f'{self.abs_path} cache_entry last modified time: {self.cache_entry["last_modified_time"]}')
        #log.debug(f'{self.abs_path} checksum: {self.checksum}')
        #log.debug(f'{self.abs_path} cache_entry checksum: {self.cache_entry["checksum"]}')

		if self.cache_entry is None:

			return True

		return (	self.last_modified_time > self.cache_entry['last_modified_time']
				and self.checksum != self.cache_entry['checksum'])


	def value_properties(self) -> dict:

		result = super().value_properties()
		result['last_modified_time'] = self.last_modified_time
		result['checksum'] = self.checksum

		return result



class DirectoryArtifact(FilesystemArtifact):

	# TODO userdoc

	def __init__(
			self, 
			abs_path=None,
            cache_entry=None, 
            requisite_operation=None, 
            requisite_output_name=None):

		super().__init__(abs_path, cache_entry, requisite_operation, requisite_output_name)


	def init_from_cache(self, cache_entry):

		super().init_from_cache(cache_entry)

		self.abs_path = cache_entry['abs_path']


	def __str__(self):

		if hasattr(self, 'abs_path'):

			return f'{self.pre_str()}{self.abs_path}/{self.post_str()}'

		return f'{self.pre_str()}unresolved DirectoryArtifact{self.post_str()}'


	def filesystem_counterpart_exists(self) -> bool:

		if not os.path.isdir(self.abs_path):

			#log.debug(f'{self.abs_path} is not dir')
			pass

		return os.path.isdir(self.abs_path)


	def filesystem_counterpart_has_changed(self) -> bool:

		# If the previous value exists, we consider it to be unchanged since
		# the last build. The contents of the directory do not matter for a
		# DirectoryArtifact -- only the existence of the directory.

		return False



class DirectoryTreeArtifact(FilesystemArtifact):

	# TODO userdoc

	def __init__(
			self, 
			abs_path=None,
            cache_entry=None, 
            requisite_operation=None, 
            requisite_output_name=None):

		super().__init__(abs_path, cache_entry, requisite_operation, requisite_output_name)


	def __str__(self):

		return f'{self.pre_str()}{self.abs_path}/...{self.post_str()}'


	def filesystem_counterpart_exists(self) -> bool:

		return os.path.isdir(self.abs_path)


	def filesystem_counterpart_has_changed(self) -> bool:

		if self.cache_entry is None:

			return True

		if self.last_modified_time > self.cache_entry['last_modified_time']:
			log.warning(f'{self.abs_path} last modified time has changed since previous build')
			return True

		return False


	def value_properties(self) -> dict:

		# TODO Have the parent class do more of this. This class should not
		# have to append the existing dict. It should just have to return a
		# dict of things it needs in its own cache record.
		# The parent class should also take care of ensuring there are no
		# field name conflicts.
		result = super().value_properties()
		result['last_modified_time'] = self.last_modified_time

		return result


class StringArtifact(Artifact):

	# TODO userdoc

	def __init__(
			self, value: str | None = None, 
			cache_entry: dict | None = None,
            requisite_operation=None, 
            requisite_output_name=None):

		super().__init__(cache_entry, requisite_operation, requisite_output_name)

		if not cache_entry:

			assert value is not None
			assert isinstance(value, str)

			self.value = value


	def init_from_cache(self, cache_entry):

		super().init_from_cache(cache_entry)

		self.value = cache_entry['value']


	def __str__(self):

		assert hasattr(self, 'value')

		# TODO Too much code depends on str(some_string_artifact) returning self.value
		#return f'{self.pre_str()}{self.value}{self.post_str()}'
		return f'{self.value}'


	def has_filesystem_counterpart(self) -> bool:

		return False


	def signature_properties(self) -> dict:

		result = super().signature_properties()
		result['value'] = self.value

		return result


class NoneArtifact(Artifact):
	"""
	Represents an artifact with no value. Needed for Settings where all that matters is the
	existence of the Setting.
	"""

	def __init__(
			self, 
            cache_entry=None, 
            requisite_operation=None, 
            requisite_output_name=None):

		super().__init__(cache_entry, requisite_operation, requisite_output_name)


	def init_from_cache(self, cache_entry):

		pass


	def __str__(self):

		return f'{self.pre_str()}None{self.post_str()}'


	def has_filesystem_counterpart(self) -> bool:

		return False


	def signature_properties(self) -> dict:

		result = super().signature_properties()

		return result


	def value_properties(self) -> dict:

		result = super().value_properties()

		return result


class DictOfArtifacts(Artifact):

	@staticmethod
	def preload_list(cache_entry):

		result = []

		for signature in cache_entry['artifacts'].values():

			result.append(signature)

		return result


	def __init__(
			self,
            cache_entry=None, 
            requisite_operation=None, 
            requisite_output_name=None):

		self.artifacts = {}

		super().__init__(cache_entry, requisite_operation, requisite_output_name)


	def init_from_cache(self, cache_entry):

		super().init_from_cache(cache_entry)

		for key, cache_signature in cache_entry['artifacts'].items():

			# Get the artifact from the artifact registry, loading it from
			# cache if it's not already in the artifact registry.
			cached_artifact = get_registered_artifact(cache_signature)
			self.artifacts[key] = cached_artifact


	def save_to_cache(self):

		for artifact in self.artifacts.values():

			artifact.save_to_cache()

		super().save_to_cache()


	def has_filesystem_counterpart(self) -> bool:

		# TODO Is this, in fact, true if any contained artifact has a filesystem counterpart?
		return False


	def __str__(self):

		artifact_strs = []

		for key, _artifact in self.artifacts.items():

			artifact_strs.append(f'{key}: {_artifact}')

		artifacts_str = ', '.join(artifact_strs)

		return f'{self.pre_str()}{{{artifacts_str}}}{self.post_str()}'


	def add_dependent_operation(self, dependent_operation): #: pajama.impl.operation.Operation):

		"""
		Let the artifact know of an operation which depends on it. Dependent operations need to be
		notified when the artifact is marked ready.

		Args:
			dependent_operation: The operation which depends on this artifact.
		"""

		assert isinstance(dependent_operation, pajama.impl.operation.Operation)

		super().add_dependent_operation(dependent_operation)

		# The operation needs to be a dependent operation of all the artifacts contained in this
		# DictOfArtifacts.
		for artifact in self.artifacts.values():

			artifact.add_dependent_operation(dependent_operation)


	def items(self):

		return self.artifacts.items()


	def signature_properties(self) -> dict:

		result = super().signature_properties()

		artifacts = {}

		for key, _artifact in self.artifacts.items():

			artifacts[key] = _artifact.cache_signature

		assert artifacts

		result['artifacts'] = artifacts

		return result


	def value_properties(self) -> dict:

		result = super().value_properties()

		return result


class VersionArtifact(Artifact):

	def __init__(
			self, 
			version: pajama.impl.version.Version | None = None, 
			cache_entry: dict | None = None,
            requisite_operation=None, 
            requisite_output_name=None):

		super().__init__(cache_entry, requisite_operation, requisite_output_name)

		assert version is None or isinstance(version, pajama.impl.version.Version)
		assert version is None or cache_entry is None

		if not cache_entry:

			assert version is not None
			assert isinstance(version, pajama.impl.version.Version)

			self.version = version


	def init_from_cache(self, cache_entry):

		super().init_from_cache(cache_entry)

		version_str = cache_entry['version_str']
		version_cls_str = cache_entry['version_cls']
		version_cls = convert.cls_str_to_cls(version_cls_str)
		self.version = version_cls(version_str)


	def __str__(self):

		return f'{self.pre_str()}{self.version!s}{self.post_str()}'


	def signature_properties(self) -> dict:
		result = super().signature_properties()
		result['version_str'] = str(self.version)
		result['version_cls'] = convert.object_to_cls_str(self.version)

		return result


	def has_filesystem_counterpart(self) -> bool:
		return False


class NamedArtifactRegistry(metaclass=singleton.Singleton):

	def __init__(self):

		self.named_artifacts = {}


	def add(self, artifact: Artifact, artifact_name: str):

		log.debug(f'NamedArtifactRegistry.add({artifact_name})', tag='artifact')

		if artifact_name in self.named_artifacts:

			#log.warning(f'NamedArtifactRegistry.add({artifact!s}{artifact_name}): already in registry')
			#log.debug_stack()
			return

		artifact.name = artifact_name
		self.named_artifacts[artifact_name] = artifact


# TODO userdoc
def add_named_artifact(artifact: Artifact, artifact_name: str):

	NamedArtifactRegistry.instance().add(artifact, artifact_name)


# TODO userdoc
def get_named_artifact(artifact_name: str):

	assert artifact_name in NamedArtifactRegistry.instance().named_artifacts, \
		f'No named artifact with name "{artifact_name}"'

	return NamedArtifactRegistry.instance().named_artifacts[artifact_name]


def load_artifact(cache_signature):

	cache_entry = cache.get(cache_signature)
	cls_str = cache_entry['cls']
	cls = convert.cls_str_to_cls(cls_str)
	artifact = cls(cache_entry=cache_entry)

	# Artifacts loaded from cache are already ready, but we rely on the caller
	# to mark them ready, because resolve() also notifies dependent
	# operations, which may not yet be loaded.

	return artifact


class ArtifactRegistry(metaclass=singleton.Singleton):

	# TODO the purpose of this class is unclear

	def __init__(self):

		self.artifacts = {}


	def register_artifact(self, artifact: Artifact):

		assert artifact is not None

		# Artifacts must be ready, because they are indexed by their cache
		# signature, which cannot be determined until the artifact is ready.
		assert artifact.is_resolved

		# TODO We sometimes create two artifacts with the same signature.
		# Is this a problem? Answer: No. They're just duplicates.
		# if artifact.cache_signature in self.artifacts:
		# log.warning(
		# f'{artifact.cache_signature} already in ArtifactRegistry')

		self.artifacts[artifact.cache_signature] = artifact


	# TODO This is a misnomer. It doesn't just get a registered artifact. It loads the artifact
	# from cache if it's not already in the registry.
	def get_registered_artifact(self, cache_signature: str):

		if cache_signature not in self.artifacts:

			# TODO exception instead
			assert cache.contains(cache_signature), f'{cache_signature} not in cache'

			artifact = load_artifact(cache_signature)
			assert artifact is not None
			self.artifacts[cache_signature] = artifact

		# TODO can we be sure the artifact exists?
		return self.artifacts[cache_signature]


def register_artifact(artifact: Artifact):

	ArtifactRegistry.instance().register_artifact(artifact)


def get_registered_artifact(cache_signature: str):

	return ArtifactRegistry.instance().get_registered_artifact(cache_signature)


# TODO consolidate with ListOfToolArtifacts and ListOfStringArtifacts. 
class ListOfArtifacts(Artifact):

	@staticmethod
	def preload_list(cache_entry):

		result = []

		for signature in cache_entry['signatures']:

			result.append(signature)

		return result


	def __init__(
			self, 
            cache_entry=None, 
            requisite_operation=None, 
            requisite_output_name=None):

		self.artifacts = []

		super().__init__(cache_entry, requisite_operation, requisite_output_name)


	def __iter__(self):

		return iter(self.artifacts)


	def __next__(self):

		return next(self.artifacts)


	def init_from_cache(self, cache_entry):

		super().init_from_cache(cache_entry)

		for signature in cache_entry['signatures']:

			assert isinstance(signature, str)

			# Get the artifact from the artifact registry, loading it from
			# cache if it's not already in the artifact registry.
			artifact = load_artifact(signature)
			self.artifacts.append(artifact)
			artifact.resolve() # TODO needed?


	def save_to_cache(self):

		for artifact in self.artifacts:

			artifact.save_to_cache()

		super().save_to_cache()


	def append(
			self,
			artifact):

		assert isinstance(artifact, Artifact)

		# TODO Establish a dependency between the artifact being appended and 
		# this ListOfArtifacts artifact.
		self.artifacts.append(artifact)


	def has_filesystem_counterpart(self) -> bool:

		# A ListOfArtifacts artifact exists only in memory or in the cache. Even if the artifacts 
		# it contains have filesystem counterparts, the ListOfArtifacts artifact itself does not. 
		# TODO Confirm this
		return False


	def __str__(self):

		return f'{self.pre_str()}list of {len(self.artifacts)} artifacts{self.post_str()}'


	def signatures(self):

		result = []

		for artifact in self.artifacts:

			result.append(artifact.cache_signature)

		return result


	def signature_properties(self) -> dict:

		result = super().signature_properties()

		result['signatures'] = self.signatures()

		return result



class ListOfOperations(Artifact):

	@staticmethod
	def preload_list(cache_entry):

		result = []

		for signature in cache_entry['signatures']:

			result.append(signature)

		return result


	def __init__(
			self,
            cache_entry=None, 
            requisite_operation=None, 
            requisite_output_name=None):

		self.operations = []

		super().__init__(cache_entry, requisite_operation, requisite_output_name)


	def init_from_cache(self, cache_entry):

		super().init_from_cache(cache_entry)

		for signature in cache_entry['signatures']:

			assert isinstance(signature, str)

			# Get the artifact from the artifact registry, loading it from
			# cache if it's not already in the artifact registry.
			operation = pajama.impl.operation.get_operation(signature)
			self.operations.append(operation)
			Artifact.add_operation_fn(operation)


	def save_to_cache(self):

		for operation in self.operations:

			operation.save_to_cache()

		super().save_to_cache()


	def append(
			self,
			operation):

		assert isinstance(operation, pajama.impl.operation.Operation)

		self.operations.append(operation)


	def has_filesystem_counterpart(self) -> bool:

		return False


	def __str__(self):

		return f'{self.pre_str()}list of {len(self.operations)} operations{self.post_str()}'


	def signatures(self):

		result = []

		for operation in self.operations:

			result.append(operation.cache_signature)

		return result


	def signature_properties(self) -> dict:

		result = super().signature_properties()

		result['signatures'] = self.signatures()

		return result



class ListOfStringArtifacts(Artifact):

	@staticmethod
	def preload_list(cache_entry):

		result = []

		for signature in cache_entry['signatures']:

			result.append(signature)

		return result


	def __init__(
			self,
            cache_entry=None, 
            requisite_operation=None, 
            requisite_output_name=None):

		self.artifacts = []

		super().__init__(cache_entry, requisite_operation, requisite_output_name)


	def init_from_cache(self, cache_entry):

		super().init_from_cache(cache_entry)

		for signature in cache_entry['signatures']:

			assert isinstance(signature, str)

			# Get the artifact from the artifact registry, loading it from
			# cache if it's not already in the artifact registry.
			artifact = get_registered_artifact(signature)
			self.artifacts.append(artifact)


	def save_to_cache(self):

		for artifact in self.artifacts:

			artifact.save_to_cache()

		super().save_to_cache()


	def append(
			self,
			string):

		assert isinstance(string, str)

		self.artifacts.append(StringArtifact(string))


	def has_filesystem_counterpart(self) -> bool:

		return False


	def __str__(self):

		artifact_strs = []

		for artifact in self.artifacts:

			artifact_strs.append(str(artifact))

		artifacts_str = ','.join(artifact_strs)

		return f'{self.pre_str()}strings [{artifacts_str}]{self.post_str()}'


	def values(self):

		result = []

		for artifact in self.artifacts:

			result.append(artifact.value)

		return result


	def signature_properties(self) -> dict:

		result = super().signature_properties()

		result['values'] = self.values()

		return result


	def value_properties(self) -> dict:

		result = super().value_properties()
		signatures = []

		assert self.artifacts

		for artifact in self.artifacts:

			signatures.append(artifact.cache_signature)

		result['signatures'] = signatures

		return result
