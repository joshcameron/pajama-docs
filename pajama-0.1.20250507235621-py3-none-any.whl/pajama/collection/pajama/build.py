import os

import pajama.impl.build as build
import pajama.impl.exception as exception

import pajama.artifact as artifact

def include(directory_name):

	"""
	Include the specified directory (which means look for a .pajama file in
	it).

	Args: 
		directory_name (str): The name of the directory to include.
	"""

	exception.type_check('directory_name', directory_name, str)

	input_artifacts = {}

	# TODO Should the operation should do this, and use build.current_source_dir
	# TODO does os.getcwd() return an abs path?
	directory_path = os.path.join(os.getcwd(), directory_name)

	if not os.path.isdir(directory_path):

		raise exception.IncludeDirectoryNotFound(directory_name)

	build_file_abs_path = os.path.join(directory_path, '.pajama')

	if not os.path.isfile(build_file_abs_path):

		raise exception.IncludeFileNotFound(build_file_abs_path)

	input_artifacts['build_file'] = artifact.FileArtifact(build_file_abs_path)

	build.instance().include(input_artifacts)
