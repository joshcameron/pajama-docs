import os

import pajama.impl.cpp as impl
from pajama.impl import exception, tool, tool_selection_action
from pajama import artifact, settings, tool_artifact


# TODO This code is nearly identical to libtool.select(). Refactor.
# TODO This doesn't work if the build wants to specify any one of several
# acceptable compilers. This function -- and ToolSelectionAction -- should
# take a list of objects specifying acceptable tools and version ranges, in
# order of preference.
def select_compiler(
		tool_id: str, 
		min_version: str | None = None, 
		max_version: str | None = None):

	"""
	Request the use of the specified compiler in the specified version range.

	Args:
		tool_id: The id of the compiler to use.
		min_version: The minimum version of the compiler to use.
		max_version: The maximum version of the compiler to use.
	"""

	exception.type_check('tool_id', tool_id, str)
	exception.type_check('min_version', min_version, (str, type(None)))
	exception.type_check('max_version', max_version, (str, type(None)))

	# TODO also accept StringArtifact or Version for min_version, max_version?
	# TODO preferred_version = Version.LATEST (vs Version.EARLIEST)
	# TODO allow preferred version to be a specific version?

	tool_cls = tool.get_tool_cls(tool_id)

	# The specified tool should be a compiler
	# TODO raise an exception instead of asserting
	# TODO tools should have a tool_type in addition to a tool_id. tool_type should be a str,
	# and users should be able to query for available tools by tool_type.
	assert isinstance(tool_cls, type(impl.Compiler))

	input_artifacts = {}

	input_artifacts['tool_id'] = artifact.StringArtifact(tool_id)

	if min_version:

		input_artifacts['min_version'] = \
			artifact.VersionArtifact(tool_cls.version_from_str(min_version))

	if max_version:

		input_artifacts['max_version'] = \
			artifact.VersionArtifact(tool_cls.version_from_str(max_version))

	selection_action = tool_selection_action.ToolSelectionAction(input_artifacts)

	assert 'tool' in selection_action.output_artifacts

	# log.debug(f'cpp.compiler tool_artifact = {id(tool_artifact)}')

	# Push compiler onto tool stack, so it will be used for subsequent
	# compile actions. At this point, the tool artifact is a placeholder --
	# the actual compiler to be used has not been discovered or selected.
	#assert tool_artifact is not None

	assert selection_action.output_artifacts['tool'] is not None
	assert isinstance(selection_action.output_artifacts['tool'], tool_artifact.ToolArtifact)
	settings.set('cpp.compiler', selection_action.output_artifacts['tool'])


def compile_to_object(
		src_file: str | artifact.FileArtifact, 
		dst_file_name: str | None=None):

	"""
	Compile a C++ source file to an object file.

	Args:
		src_file: The source file to compile.
		dst_file_name: The name of the object file to create. If None, the object file \
			will be created in the current build directory with a name based on the source file \
			name, with the appropriate extension for an object file on this operating system.

	"""

	exception.type_check('src_file', src_file, (artifact.FileArtifact, str))
	exception.type_check('dst_file_name', dst_file_name, (str, type(None)))

	input_artifacts = {}

	if isinstance(src_file, artifact.FileArtifact):

		input_artifacts['src_file'] = src_file

	elif isinstance(src_file, str):

		input_artifacts['src_file'] = artifact.FileArtifact(os.path.abspath(src_file))

	else:

		raise TypeError()


	if dst_file_name:

		assert isinstance(dst_file_name, str)

		input_artifacts['dst_file_name'] = artifact.StringArtifact(dst_file_name)

	compiler_tool_artifact = settings.get('cpp.compiler')

	# TODO raise an exception: tool used before it is selected
	assert compiler_tool_artifact is not None
	assert isinstance(compiler_tool_artifact, tool_artifact.ToolArtifact)

	# Instantiate a compile action to perform the compile. 
	tool_cls = tool.get_tool_cls(compiler_tool_artifact.tool_id)

	assert isinstance(tool_cls, type(impl.Compiler))

	compile_action = tool_cls.create_compile_to_object_action(input_artifacts)

	# We leave it to the compile action to determine the path of the object file and create the
	# FileArtifact for it. But we assert that the compile action has done so.
	assert 'object_file' in compile_action.output_artifacts

	return compile_action.output_artifacts['object_file']


#def compile_to_executable(
#		src_file: str | artifact.FileArtifact,
#		flags=None,
#		dst_file_name: str | None=None):

def compile_to_executable(
		src_file: str | artifact.FileArtifact,
		dst_file_name: str | None=None,
		static_lib: artifact.FileArtifact | None=None, # TODO link to multiple libs
		dynamic_lib: artifact.FileArtifact | None=None): # TODO link to multiple libs

	"""
	Compile a C++ source file to an executable file.

	Args:
		src_file: The source file to compile.
		dst_file_name: The name of the execuable file to create. If None, the execuable file \
			will be created in the current build directory with the default name given to an \
			executable by the current compiler. 

	"""

	exception.type_check('src_file', src_file, (artifact.FileArtifact, str))
	exception.type_check('dst_file_name', dst_file_name, (str, type(None)))
	exception.type_check('static_lib', static_lib, (artifact.FileArtifact, type(None)))
	exception.type_check('dynamic_lib', dynamic_lib, (artifact.FileArtifact, type(None)))

	compiler_tool_artifact = settings.get('cpp.compiler')
	# TODO raise an exception: tool used before it is selected
	assert compiler_tool_artifact is not None
	assert isinstance(compiler_tool_artifact, tool_artifact.ToolArtifact)
	# Instantiate a compile action to perform the compile. 
	tool_cls = tool.get_tool_cls(compiler_tool_artifact.tool_id)
	assert isinstance(tool_cls, type(impl.Compiler))

	input_artifacts = {}

	if isinstance(src_file, artifact.FileArtifact):

		input_artifacts['src_file'] = src_file

	elif isinstance(src_file, str):

		input_artifacts['src_file'] = artifact.FileArtifact(os.path.abspath(src_file))

	else:

		raise TypeError()


	if static_lib:

		input_artifacts['static_lib'] = static_lib

	if dynamic_lib:

		input_artifacts['dynamic_lib'] = dynamic_lib

	if dst_file_name:

		assert isinstance(dst_file_name, str)

		input_artifacts['dst_file_name'] = artifact.StringArtifact(dst_file_name)

	compile_action = tool_cls.create_compile_to_executable_action(input_artifacts)

	# We leave it to the compile action to determine the path of the object file and create the
	# FileArtifact for it. But we assert that the compile action has done so.
	assert 'executable_file' in compile_action.output_artifacts

	return compile_action.output_artifacts['executable_file']


"""

def select_linker(tool_id: str, min_version: str | None = None, max_version: str | None = None):

	#Request the use of the specified linker in the specified version range.

	#Args:
	#	tool_id: The id of the linker to use.
	#	min_version: The minimum version of the linker to use.
	#	max_version: The maximum version of the linker to use.

	# TODO preferred_version = Version.LATEST (vs Version.EARLIEST)
	# TODO allow preferred version to be a specific version?

	# The specified tool should be a linker
	assert isinstance(tool.get(tool_id), type(impl.Linker))

	selection_action = tool_selection_action.ToolSelectionAction(
		tool_id, 
		min_version=min_version, 
		max_version=max_version)

	tool_artifact = selection_action.output_artifacts['tool']
	# log.debug(f'cpp.linker tool_artifact = {id(tool_artifact)}')

	# Push linker onto tool stack, so it will be used for subsequent
	# link actions. At this point, the tool artifact is a placeholder --
	# the actual linker to be used has not been discovered or selected.
	assert tool_artifact is not None

	settings.set('cpp.linker', tool_artifact)
"""


def link_library(
		object_files: list, 
		dst_file_name: str):

	"""
	Link object files into a static or dynamic library.

	Args:
		object_files: The object files to link.
		dst_file_name: The name of the library to create. 

	"""

	exception.type_check('object_files', object_files, (list))
	exception.type_check('dst_file_name', dst_file_name, (str))

	input_artifacts = {}
	input_artifacts['object_files'] = artifact.ListOfArtifacts()

	for object_file in object_files:

		if isinstance(object_file, artifact.FileArtifact):

			input_artifacts['object_files'].append(object_file)

		elif isinstance(object_file, str):

			input_artifacts['object_files'].append(
				artifact.FileArtifact(os.path.abspath(object_file)))

		else:

			# TODO raise an exception. Should find a way to type_check the list
			raise TypeError()


	input_artifacts['dst_file_name'] = artifact.StringArtifact(dst_file_name)

	linker_tool_artifact = settings.get('cpp.linker')

	# TODO raise an exception: tool used before it is selected
	assert linker_tool_artifact is not None
	assert isinstance(linker_tool_artifact, tool_artifact.ToolArtifact)

	# Instantiate a compile action to perform the compile. 
	tool_cls = tool.get_tool_cls(linker_tool_artifact.tool_id)

	assert isinstance(tool_cls, type(impl.Linker))

	link_library_action = tool_cls.create_link_library_action(input_artifacts)

	# We leave it to the compile action to determine the path of the object file and create the
	# FileArtifact for it. But we assert that the compile action has done so.
	assert 'library_file' in link_library_action.output_artifacts

	return link_library_action.output_artifacts['library_file']
